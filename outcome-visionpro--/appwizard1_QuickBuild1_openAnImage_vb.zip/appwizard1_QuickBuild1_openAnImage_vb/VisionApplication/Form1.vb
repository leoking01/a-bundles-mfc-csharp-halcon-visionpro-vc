Imports Cognex.VisionPro

Public Class Form1

Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
  ' set the title of this application using the title supplied in the generated control
  'Me.Text = visionControl1.ApplicationName;
End Sub

'Form overrides dispose to clean up the component list.
Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
  If disposing Then
    If Not (components Is Nothing) Then
      components.Dispose()
    End If
    Dim frameGrabbers As New CogFrameGrabbers
    For Each fg As Cognex.VisionPro.ICogFrameGrabber In frameGrabbers
      fg.Disconnect(False)
    Next
  End If
  MyBase.Dispose(disposing)
End Sub

Private Sub FormClosingHandler(sender As System.Object, e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
  VisionControl1.Close()
End Sub

End Class
