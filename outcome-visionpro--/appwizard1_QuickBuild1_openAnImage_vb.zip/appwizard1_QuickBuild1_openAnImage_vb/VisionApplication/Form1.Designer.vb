<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
Me.VisionControl1 = New VisionControl.VisionControl
Me.SuspendLayout()
'
'VisionControl1
'
Me.VisionControl1.Dock = System.Windows.Forms.DockStyle.Fill
Me.VisionControl1.Location = New System.Drawing.Point(0, 0)
Me.VisionControl1.Name = "VisionControl1"
Me.VisionControl1.Size = New System.Drawing.Size(791, 429)
Me.VisionControl1.TabIndex = 0
'
'Form1
'
Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
Me.ClientSize = New System.Drawing.Size(791, 429)
Me.Controls.Add(Me.VisionControl1)
Me.Name = "Form1"
Me.Text = "Form1"
Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
Me.ResumeLayout(False)

End Sub
    Friend WithEvents VisionControl1 As VisionControl.VisionControl

End Class
