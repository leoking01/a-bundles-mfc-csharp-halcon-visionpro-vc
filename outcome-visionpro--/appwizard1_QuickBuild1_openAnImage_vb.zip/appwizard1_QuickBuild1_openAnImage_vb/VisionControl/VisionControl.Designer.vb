' cognex.wizard.initializecomponent
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class VisionControl
    Inherits System.Windows.Forms.UserControl

    'UserControl1 overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            If (Not mJM Is Nothing) Then
              mJM.Shutdown()
            End If
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.tabPage_Job0_CogJob1 = New System.Windows.Forms.TabPage()
        Me.label_controlErrorMessage = New System.Windows.Forms.Label()
        Me.pictureBox_Logo = New System.Windows.Forms.PictureBox()
        Me.panel4 = New System.Windows.Forms.Panel()
        Me.panel5 = New System.Windows.Forms.Panel()
        Me.CogRecordsDisplay1 = New Cognex.VisionPro.CogRecordsDisplay()
        Me.splitter2 = New System.Windows.Forms.Splitter()
        Me.panel6 = New System.Windows.Forms.Panel()
        Me.tabControl_JobTabs = New System.Windows.Forms.TabControl()
        Me.tabPage_JobN_JobStatistics = New System.Windows.Forms.TabPage()
        Me.button_ResetStatistics = New System.Windows.Forms.Button()
        Me.button_ResetStatisticsForAllJobs = New System.Windows.Forms.Button()
        Me.groupBox_AcquisitionResults = New System.Windows.Forms.GroupBox()
        Me.textBox_JobN_TotalAcquisitionOverruns = New System.Windows.Forms.TextBox()
        Me.label_AcquisitionResults_Overruns = New System.Windows.Forms.Label()
        Me.textBox_JobN_TotalAcquisitionErrors = New System.Windows.Forms.TextBox()
        Me.label_AcquisitionResults_Errors = New System.Windows.Forms.Label()
        Me.textBox_JobN_TotalAcquisitions = New System.Windows.Forms.TextBox()
        Me.label_AcquisitionResults_TotalAcquisitions = New System.Windows.Forms.Label()
        Me.groupBox_JobThroughput = New System.Windows.Forms.GroupBox()
        Me.label_JobThroughput_persec = New System.Windows.Forms.Label()
        Me.textBox_JobN_MaxThroughput = New System.Windows.Forms.TextBox()
        Me.textBox_JobN_MinThroughput = New System.Windows.Forms.TextBox()
        Me.label_JobThroughput_Max = New System.Windows.Forms.Label()
        Me.label_JobThroughput_Min = New System.Windows.Forms.Label()
        Me.textBox_JobN_Throughput = New System.Windows.Forms.TextBox()
        Me.label_JobThroughput_TotalThroughput = New System.Windows.Forms.Label()
        Me.groupBox_JobResults = New System.Windows.Forms.GroupBox()
        Me.label_JobResults_Percent = New System.Windows.Forms.Label()
        Me.textBox_JobN_TotalAccept_Percent = New System.Windows.Forms.TextBox()
        Me.textBox_JobN_TotalWarning = New System.Windows.Forms.TextBox()
        Me.textBox_JobN_TotalError = New System.Windows.Forms.TextBox()
        Me.label_JobResults_Error = New System.Windows.Forms.Label()
        Me.label_JobResults_Warning = New System.Windows.Forms.Label()
        Me.textBox_JobN_TotalReject = New System.Windows.Forms.TextBox()
        Me.label_JobResults_Reject = New System.Windows.Forms.Label()
        Me.textBox_JobN_TotalAccept = New System.Windows.Forms.TextBox()
        Me.label_JobResults_Accept = New System.Windows.Forms.Label()
        Me.textBox_JobN_TotalIterations = New System.Windows.Forms.TextBox()
        Me.label_JobResults_TotalIterations = New System.Windows.Forms.Label()
        Me.label_ResultBar = New System.Windows.Forms.Label()
        Me.btnRun = New System.Windows.Forms.Button()
        Me.label_Online = New System.Windows.Forms.Label()
        Me.CogJobResultHistoryCollectionEdit1 = New Cognex.VisionPro.QuickBuild.CogJobResultHistoryCollectionEdit()
        Me.groupBox_DividerLine = New System.Windows.Forms.GroupBox()
        Me.applicationErrorProvider = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.label_Login = New System.Windows.Forms.Label()
        Me.button_Configuration = New System.Windows.Forms.Button()
        Me.comboBox_Login = New System.Windows.Forms.ComboBox()
        Me.button_SaveSettings = New System.Windows.Forms.Button()
        Me.panel3 = New System.Windows.Forms.Panel()
        Me.splitter1 = New System.Windows.Forms.Splitter()
        Me.checkBox_LiveDisplay = New System.Windows.Forms.CheckBox()
        Me.button_About = New System.Windows.Forms.Button()
        Me.btnRunCont = New System.Windows.Forms.Button()
        Me.panel1 = New System.Windows.Forms.Panel()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        CType(Me.pictureBox_Logo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panel4.SuspendLayout()
        Me.panel5.SuspendLayout()
        Me.panel6.SuspendLayout()
        Me.tabControl_JobTabs.SuspendLayout()
        Me.tabPage_JobN_JobStatistics.SuspendLayout()
        Me.groupBox_AcquisitionResults.SuspendLayout()
        Me.groupBox_JobThroughput.SuspendLayout()
        Me.groupBox_JobResults.SuspendLayout()
        CType(Me.applicationErrorProvider, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panel3.SuspendLayout()
        Me.panel1.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'tabPage_Job0_CogJob1
        '
        Me.tabPage_Job0_CogJob1.AutoScroll = True
        Me.tabPage_Job0_CogJob1.Location = New System.Drawing.Point(4, 22)
        Me.tabPage_Job0_CogJob1.Name = "tabPage_Job0_CogJob1"
        Me.tabPage_Job0_CogJob1.Size = New System.Drawing.Size(467, 409)
        Me.tabPage_Job0_CogJob1.TabIndex = 0
        Me.tabPage_Job0_CogJob1.Text = "CogJob1"
        '
        'label_controlErrorMessage
        '
        Me.label_controlErrorMessage.Dock = System.Windows.Forms.DockStyle.Fill
        Me.label_controlErrorMessage.Location = New System.Drawing.Point(3, 3)
        Me.label_controlErrorMessage.Name = "label_controlErrorMessage"
        Me.label_controlErrorMessage.Size = New System.Drawing.Size(901, 449)
        Me.label_controlErrorMessage.TabIndex = 30
        Me.label_controlErrorMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pictureBox_Logo
        '
        Me.pictureBox_Logo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pictureBox_Logo.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pictureBox_Logo.Location = New System.Drawing.Point(0, 432)
        Me.pictureBox_Logo.Name = "pictureBox_Logo"
        Me.pictureBox_Logo.Size = New System.Drawing.Size(475, 17)
        Me.pictureBox_Logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.pictureBox_Logo.TabIndex = 27
        Me.pictureBox_Logo.TabStop = False
        '
        'panel4
        '
        Me.panel4.Controls.Add(Me.panel5)
        Me.panel4.Controls.Add(Me.label_ResultBar)
        Me.panel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panel4.Location = New System.Drawing.Point(0, 0)
        Me.panel4.Name = "panel4"
        Me.panel4.Padding = New System.Windows.Forms.Padding(3, 5, 3, 3)
        Me.panel4.Size = New System.Drawing.Size(913, 490)
        Me.panel4.TabIndex = 0
        '
        'panel5
        '
        Me.panel5.Controls.Add(Me.CogRecordsDisplay1)
        Me.panel5.Controls.Add(Me.splitter2)
        Me.panel5.Controls.Add(Me.panel6)
        Me.panel5.Controls.Add(Me.label_controlErrorMessage)
        Me.panel5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panel5.Location = New System.Drawing.Point(3, 32)
        Me.panel5.Name = "panel5"
        Me.panel5.Padding = New System.Windows.Forms.Padding(3)
        Me.panel5.Size = New System.Drawing.Size(907, 455)
        Me.panel5.TabIndex = 26
        '
        'CogRecordsDisplay1
        '
        Me.CogRecordsDisplay1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.CogRecordsDisplay1.Location = New System.Drawing.Point(3, 3)
        Me.CogRecordsDisplay1.Name = "CogRecordsDisplay1"
        Me.CogRecordsDisplay1.SelectedRecordKey = Nothing
        Me.CogRecordsDisplay1.ShowRecordsDropDown = True
        Me.CogRecordsDisplay1.Size = New System.Drawing.Size(420, 449)
        Me.CogRecordsDisplay1.Subject = Nothing
        Me.CogRecordsDisplay1.TabIndex = 31
        '
        'splitter2
        '
        Me.splitter2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.splitter2.Dock = System.Windows.Forms.DockStyle.Right
        Me.splitter2.Location = New System.Drawing.Point(423, 3)
        Me.splitter2.Name = "splitter2"
        Me.splitter2.Size = New System.Drawing.Size(6, 449)
        Me.splitter2.TabIndex = 28
        Me.splitter2.TabStop = False
        '
        'panel6
        '
        Me.panel6.Controls.Add(Me.tabControl_JobTabs)
        Me.panel6.Controls.Add(Me.pictureBox_Logo)
        Me.panel6.Dock = System.Windows.Forms.DockStyle.Right
        Me.panel6.Location = New System.Drawing.Point(429, 3)
        Me.panel6.Name = "panel6"
        Me.panel6.Size = New System.Drawing.Size(475, 449)
        Me.panel6.TabIndex = 27
        '
        'tabControl_JobTabs
        '
        Me.tabControl_JobTabs.Controls.Add(Me.tabPage_JobN_JobStatistics)
        Me.tabControl_JobTabs.Controls.Add(Me.tabPage_Job0_CogJob1)
        Me.tabControl_JobTabs.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tabControl_JobTabs.Location = New System.Drawing.Point(0, 0)
        Me.tabControl_JobTabs.Name = "tabControl_JobTabs"
        Me.tabControl_JobTabs.SelectedIndex = 0
        Me.tabControl_JobTabs.Size = New System.Drawing.Size(475, 432)
        Me.tabControl_JobTabs.TabIndex = 28
        Me.tabControl_JobTabs.Tag = ""
        '
        'tabPage_JobN_JobStatistics
        '
        Me.tabPage_JobN_JobStatistics.AutoScroll = True
        Me.tabPage_JobN_JobStatistics.Controls.Add(Me.button_ResetStatistics)
        Me.tabPage_JobN_JobStatistics.Controls.Add(Me.button_ResetStatisticsForAllJobs)
        Me.tabPage_JobN_JobStatistics.Controls.Add(Me.groupBox_AcquisitionResults)
        Me.tabPage_JobN_JobStatistics.Controls.Add(Me.groupBox_JobThroughput)
        Me.tabPage_JobN_JobStatistics.Controls.Add(Me.groupBox_JobResults)
        Me.tabPage_JobN_JobStatistics.Location = New System.Drawing.Point(4, 22)
        Me.tabPage_JobN_JobStatistics.Name = "tabPage_JobN_JobStatistics"
        Me.tabPage_JobN_JobStatistics.Size = New System.Drawing.Size(467, 406)
        Me.tabPage_JobN_JobStatistics.TabIndex = 0
        Me.tabPage_JobN_JobStatistics.Text = "Job Statistics"
        '
        'button_ResetStatistics
        '
        Me.button_ResetStatistics.Location = New System.Drawing.Point(35, 347)
        Me.button_ResetStatistics.Name = "button_ResetStatistics"
        Me.button_ResetStatistics.Size = New System.Drawing.Size(133, 21)
        Me.button_ResetStatistics.TabIndex = 41
        Me.button_ResetStatistics.Text = "Reset Statistics"
        '
        'button_ResetStatisticsForAllJobs
        '
        Me.button_ResetStatisticsForAllJobs.Location = New System.Drawing.Point(192, 347)
        Me.button_ResetStatisticsForAllJobs.Name = "button_ResetStatisticsForAllJobs"
        Me.button_ResetStatisticsForAllJobs.Size = New System.Drawing.Size(168, 21)
        Me.button_ResetStatisticsForAllJobs.TabIndex = 40
        Me.button_ResetStatisticsForAllJobs.Text = "Reset Statistics For All Jobs"
        '
        'groupBox_AcquisitionResults
        '
        Me.groupBox_AcquisitionResults.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.groupBox_AcquisitionResults.Controls.Add(Me.textBox_JobN_TotalAcquisitionOverruns)
        Me.groupBox_AcquisitionResults.Controls.Add(Me.label_AcquisitionResults_Overruns)
        Me.groupBox_AcquisitionResults.Controls.Add(Me.textBox_JobN_TotalAcquisitionErrors)
        Me.groupBox_AcquisitionResults.Controls.Add(Me.label_AcquisitionResults_Errors)
        Me.groupBox_AcquisitionResults.Controls.Add(Me.textBox_JobN_TotalAcquisitions)
        Me.groupBox_AcquisitionResults.Controls.Add(Me.label_AcquisitionResults_TotalAcquisitions)
        Me.groupBox_AcquisitionResults.Location = New System.Drawing.Point(22, 148)
        Me.groupBox_AcquisitionResults.Name = "groupBox_AcquisitionResults"
        Me.groupBox_AcquisitionResults.Size = New System.Drawing.Size(423, 89)
        Me.groupBox_AcquisitionResults.TabIndex = 39
        Me.groupBox_AcquisitionResults.TabStop = False
        Me.groupBox_AcquisitionResults.Text = "Acquisition Results"
        '
        'textBox_JobN_TotalAcquisitionOverruns
        '
        Me.textBox_JobN_TotalAcquisitionOverruns.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textBox_JobN_TotalAcquisitionOverruns.Location = New System.Drawing.Point(207, 66)
        Me.textBox_JobN_TotalAcquisitionOverruns.Name = "textBox_JobN_TotalAcquisitionOverruns"
        Me.textBox_JobN_TotalAcquisitionOverruns.ReadOnly = True
        Me.textBox_JobN_TotalAcquisitionOverruns.Size = New System.Drawing.Size(100, 21)
        Me.textBox_JobN_TotalAcquisitionOverruns.TabIndex = 33
        Me.textBox_JobN_TotalAcquisitionOverruns.Text = "textBox2"
        Me.textBox_JobN_TotalAcquisitionOverruns.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'label_AcquisitionResults_Overruns
        '
        Me.label_AcquisitionResults_Overruns.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.label_AcquisitionResults_Overruns.Location = New System.Drawing.Point(54, 68)
        Me.label_AcquisitionResults_Overruns.Name = "label_AcquisitionResults_Overruns"
        Me.label_AcquisitionResults_Overruns.Size = New System.Drawing.Size(148, 15)
        Me.label_AcquisitionResults_Overruns.TabIndex = 32
        Me.label_AcquisitionResults_Overruns.Text = "Overruns:"
        '
        'textBox_JobN_TotalAcquisitionErrors
        '
        Me.textBox_JobN_TotalAcquisitionErrors.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textBox_JobN_TotalAcquisitionErrors.Location = New System.Drawing.Point(207, 44)
        Me.textBox_JobN_TotalAcquisitionErrors.Name = "textBox_JobN_TotalAcquisitionErrors"
        Me.textBox_JobN_TotalAcquisitionErrors.ReadOnly = True
        Me.textBox_JobN_TotalAcquisitionErrors.Size = New System.Drawing.Size(100, 21)
        Me.textBox_JobN_TotalAcquisitionErrors.TabIndex = 31
        Me.textBox_JobN_TotalAcquisitionErrors.Text = "textBox1"
        Me.textBox_JobN_TotalAcquisitionErrors.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'label_AcquisitionResults_Errors
        '
        Me.label_AcquisitionResults_Errors.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.label_AcquisitionResults_Errors.Location = New System.Drawing.Point(54, 46)
        Me.label_AcquisitionResults_Errors.Name = "label_AcquisitionResults_Errors"
        Me.label_AcquisitionResults_Errors.Size = New System.Drawing.Size(148, 15)
        Me.label_AcquisitionResults_Errors.TabIndex = 30
        Me.label_AcquisitionResults_Errors.Text = "Errors:"
        '
        'textBox_JobN_TotalAcquisitions
        '
        Me.textBox_JobN_TotalAcquisitions.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textBox_JobN_TotalAcquisitions.Location = New System.Drawing.Point(207, 22)
        Me.textBox_JobN_TotalAcquisitions.Name = "textBox_JobN_TotalAcquisitions"
        Me.textBox_JobN_TotalAcquisitions.ReadOnly = True
        Me.textBox_JobN_TotalAcquisitions.Size = New System.Drawing.Size(100, 21)
        Me.textBox_JobN_TotalAcquisitions.TabIndex = 28
        Me.textBox_JobN_TotalAcquisitions.Text = "textBox1"
        Me.textBox_JobN_TotalAcquisitions.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'label_AcquisitionResults_TotalAcquisitions
        '
        Me.label_AcquisitionResults_TotalAcquisitions.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.label_AcquisitionResults_TotalAcquisitions.Location = New System.Drawing.Point(24, 24)
        Me.label_AcquisitionResults_TotalAcquisitions.Name = "label_AcquisitionResults_TotalAcquisitions"
        Me.label_AcquisitionResults_TotalAcquisitions.Size = New System.Drawing.Size(176, 15)
        Me.label_AcquisitionResults_TotalAcquisitions.TabIndex = 27
        Me.label_AcquisitionResults_TotalAcquisitions.Text = "Total Acquisitions:"
        '
        'groupBox_JobThroughput
        '
        Me.groupBox_JobThroughput.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.groupBox_JobThroughput.Controls.Add(Me.label_JobThroughput_persec)
        Me.groupBox_JobThroughput.Controls.Add(Me.textBox_JobN_MaxThroughput)
        Me.groupBox_JobThroughput.Controls.Add(Me.textBox_JobN_MinThroughput)
        Me.groupBox_JobThroughput.Controls.Add(Me.label_JobThroughput_Max)
        Me.groupBox_JobThroughput.Controls.Add(Me.label_JobThroughput_Min)
        Me.groupBox_JobThroughput.Controls.Add(Me.textBox_JobN_Throughput)
        Me.groupBox_JobThroughput.Controls.Add(Me.label_JobThroughput_TotalThroughput)
        Me.groupBox_JobThroughput.Location = New System.Drawing.Point(22, 244)
        Me.groupBox_JobThroughput.Name = "groupBox_JobThroughput"
        Me.groupBox_JobThroughput.Size = New System.Drawing.Size(423, 89)
        Me.groupBox_JobThroughput.TabIndex = 38
        Me.groupBox_JobThroughput.TabStop = False
        Me.groupBox_JobThroughput.Text = "Job Throughput"
        '
        'label_JobThroughput_persec
        '
        Me.label_JobThroughput_persec.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.label_JobThroughput_persec.Location = New System.Drawing.Point(319, 24)
        Me.label_JobThroughput_persec.Name = "label_JobThroughput_persec"
        Me.label_JobThroughput_persec.Size = New System.Drawing.Size(96, 15)
        Me.label_JobThroughput_persec.TabIndex = 29
        Me.label_JobThroughput_persec.Text = "per sec"
        '
        'textBox_JobN_MaxThroughput
        '
        Me.textBox_JobN_MaxThroughput.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textBox_JobN_MaxThroughput.Location = New System.Drawing.Point(207, 66)
        Me.textBox_JobN_MaxThroughput.Name = "textBox_JobN_MaxThroughput"
        Me.textBox_JobN_MaxThroughput.ReadOnly = True
        Me.textBox_JobN_MaxThroughput.Size = New System.Drawing.Size(100, 21)
        Me.textBox_JobN_MaxThroughput.TabIndex = 28
        Me.textBox_JobN_MaxThroughput.Text = "textBox1"
        Me.textBox_JobN_MaxThroughput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'textBox_JobN_MinThroughput
        '
        Me.textBox_JobN_MinThroughput.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textBox_JobN_MinThroughput.Location = New System.Drawing.Point(207, 44)
        Me.textBox_JobN_MinThroughput.Name = "textBox_JobN_MinThroughput"
        Me.textBox_JobN_MinThroughput.ReadOnly = True
        Me.textBox_JobN_MinThroughput.Size = New System.Drawing.Size(100, 21)
        Me.textBox_JobN_MinThroughput.TabIndex = 27
        Me.textBox_JobN_MinThroughput.Text = "textBox1"
        Me.textBox_JobN_MinThroughput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'label_JobThroughput_Max
        '
        Me.label_JobThroughput_Max.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.label_JobThroughput_Max.Location = New System.Drawing.Point(54, 68)
        Me.label_JobThroughput_Max.Name = "label_JobThroughput_Max"
        Me.label_JobThroughput_Max.Size = New System.Drawing.Size(148, 15)
        Me.label_JobThroughput_Max.TabIndex = 26
        Me.label_JobThroughput_Max.Text = "Max:"
        '
        'label_JobThroughput_Min
        '
        Me.label_JobThroughput_Min.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.label_JobThroughput_Min.Location = New System.Drawing.Point(54, 46)
        Me.label_JobThroughput_Min.Name = "label_JobThroughput_Min"
        Me.label_JobThroughput_Min.Size = New System.Drawing.Size(148, 15)
        Me.label_JobThroughput_Min.TabIndex = 25
        Me.label_JobThroughput_Min.Text = "Min:"
        '
        'textBox_JobN_Throughput
        '
        Me.textBox_JobN_Throughput.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textBox_JobN_Throughput.Location = New System.Drawing.Point(207, 22)
        Me.textBox_JobN_Throughput.Name = "textBox_JobN_Throughput"
        Me.textBox_JobN_Throughput.ReadOnly = True
        Me.textBox_JobN_Throughput.Size = New System.Drawing.Size(100, 21)
        Me.textBox_JobN_Throughput.TabIndex = 24
        Me.textBox_JobN_Throughput.Text = "textBox1"
        Me.textBox_JobN_Throughput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'label_JobThroughput_TotalThroughput
        '
        Me.label_JobThroughput_TotalThroughput.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.label_JobThroughput_TotalThroughput.Location = New System.Drawing.Point(24, 24)
        Me.label_JobThroughput_TotalThroughput.Name = "label_JobThroughput_TotalThroughput"
        Me.label_JobThroughput_TotalThroughput.Size = New System.Drawing.Size(176, 15)
        Me.label_JobThroughput_TotalThroughput.TabIndex = 23
        Me.label_JobThroughput_TotalThroughput.Text = "Total Throughput:"
        '
        'groupBox_JobResults
        '
        Me.groupBox_JobResults.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.groupBox_JobResults.Controls.Add(Me.label_JobResults_Percent)
        Me.groupBox_JobResults.Controls.Add(Me.textBox_JobN_TotalAccept_Percent)
        Me.groupBox_JobResults.Controls.Add(Me.textBox_JobN_TotalWarning)
        Me.groupBox_JobResults.Controls.Add(Me.textBox_JobN_TotalError)
        Me.groupBox_JobResults.Controls.Add(Me.label_JobResults_Error)
        Me.groupBox_JobResults.Controls.Add(Me.label_JobResults_Warning)
        Me.groupBox_JobResults.Controls.Add(Me.textBox_JobN_TotalReject)
        Me.groupBox_JobResults.Controls.Add(Me.label_JobResults_Reject)
        Me.groupBox_JobResults.Controls.Add(Me.textBox_JobN_TotalAccept)
        Me.groupBox_JobResults.Controls.Add(Me.label_JobResults_Accept)
        Me.groupBox_JobResults.Controls.Add(Me.textBox_JobN_TotalIterations)
        Me.groupBox_JobResults.Controls.Add(Me.label_JobResults_TotalIterations)
        Me.groupBox_JobResults.Location = New System.Drawing.Point(22, 7)
        Me.groupBox_JobResults.Name = "groupBox_JobResults"
        Me.groupBox_JobResults.Size = New System.Drawing.Size(423, 133)
        Me.groupBox_JobResults.TabIndex = 37
        Me.groupBox_JobResults.TabStop = False
        Me.groupBox_JobResults.Text = "Job Results"
        '
        'label_JobResults_Percent
        '
        Me.label_JobResults_Percent.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.label_JobResults_Percent.Location = New System.Drawing.Point(375, 47)
        Me.label_JobResults_Percent.Name = "label_JobResults_Percent"
        Me.label_JobResults_Percent.Size = New System.Drawing.Size(34, 15)
        Me.label_JobResults_Percent.TabIndex = 40
        Me.label_JobResults_Percent.Text = "%"
        '
        'textBox_JobN_TotalAccept_Percent
        '
        Me.textBox_JobN_TotalAccept_Percent.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textBox_JobN_TotalAccept_Percent.Location = New System.Drawing.Point(323, 44)
        Me.textBox_JobN_TotalAccept_Percent.Name = "textBox_JobN_TotalAccept_Percent"
        Me.textBox_JobN_TotalAccept_Percent.ReadOnly = True
        Me.textBox_JobN_TotalAccept_Percent.Size = New System.Drawing.Size(52, 21)
        Me.textBox_JobN_TotalAccept_Percent.TabIndex = 39
        Me.textBox_JobN_TotalAccept_Percent.Text = "textBox1"
        Me.textBox_JobN_TotalAccept_Percent.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'textBox_JobN_TotalWarning
        '
        Me.textBox_JobN_TotalWarning.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textBox_JobN_TotalWarning.Location = New System.Drawing.Point(207, 89)
        Me.textBox_JobN_TotalWarning.Name = "textBox_JobN_TotalWarning"
        Me.textBox_JobN_TotalWarning.ReadOnly = True
        Me.textBox_JobN_TotalWarning.Size = New System.Drawing.Size(100, 21)
        Me.textBox_JobN_TotalWarning.TabIndex = 38
        Me.textBox_JobN_TotalWarning.Text = "textBox4"
        Me.textBox_JobN_TotalWarning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'textBox_JobN_TotalError
        '
        Me.textBox_JobN_TotalError.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textBox_JobN_TotalError.Location = New System.Drawing.Point(207, 111)
        Me.textBox_JobN_TotalError.Name = "textBox_JobN_TotalError"
        Me.textBox_JobN_TotalError.ReadOnly = True
        Me.textBox_JobN_TotalError.Size = New System.Drawing.Size(100, 21)
        Me.textBox_JobN_TotalError.TabIndex = 36
        Me.textBox_JobN_TotalError.Text = "textBox3"
        Me.textBox_JobN_TotalError.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'label_JobResults_Error
        '
        Me.label_JobResults_Error.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.label_JobResults_Error.Location = New System.Drawing.Point(54, 113)
        Me.label_JobResults_Error.Name = "label_JobResults_Error"
        Me.label_JobResults_Error.Size = New System.Drawing.Size(148, 15)
        Me.label_JobResults_Error.TabIndex = 35
        Me.label_JobResults_Error.Text = "Error:"
        '
        'label_JobResults_Warning
        '
        Me.label_JobResults_Warning.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.label_JobResults_Warning.Location = New System.Drawing.Point(54, 90)
        Me.label_JobResults_Warning.Name = "label_JobResults_Warning"
        Me.label_JobResults_Warning.Size = New System.Drawing.Size(148, 15)
        Me.label_JobResults_Warning.TabIndex = 34
        Me.label_JobResults_Warning.Text = "Warning:"
        '
        'textBox_JobN_TotalReject
        '
        Me.textBox_JobN_TotalReject.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textBox_JobN_TotalReject.Location = New System.Drawing.Point(207, 66)
        Me.textBox_JobN_TotalReject.Name = "textBox_JobN_TotalReject"
        Me.textBox_JobN_TotalReject.ReadOnly = True
        Me.textBox_JobN_TotalReject.Size = New System.Drawing.Size(100, 21)
        Me.textBox_JobN_TotalReject.TabIndex = 33
        Me.textBox_JobN_TotalReject.Text = "textBox2"
        Me.textBox_JobN_TotalReject.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'label_JobResults_Reject
        '
        Me.label_JobResults_Reject.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.label_JobResults_Reject.Location = New System.Drawing.Point(54, 68)
        Me.label_JobResults_Reject.Name = "label_JobResults_Reject"
        Me.label_JobResults_Reject.Size = New System.Drawing.Size(148, 15)
        Me.label_JobResults_Reject.TabIndex = 31
        Me.label_JobResults_Reject.Text = "Reject:"
        '
        'textBox_JobN_TotalAccept
        '
        Me.textBox_JobN_TotalAccept.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textBox_JobN_TotalAccept.Location = New System.Drawing.Point(207, 44)
        Me.textBox_JobN_TotalAccept.Name = "textBox_JobN_TotalAccept"
        Me.textBox_JobN_TotalAccept.ReadOnly = True
        Me.textBox_JobN_TotalAccept.Size = New System.Drawing.Size(100, 21)
        Me.textBox_JobN_TotalAccept.TabIndex = 29
        Me.textBox_JobN_TotalAccept.Text = "textBox1"
        Me.textBox_JobN_TotalAccept.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'label_JobResults_Accept
        '
        Me.label_JobResults_Accept.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.label_JobResults_Accept.Location = New System.Drawing.Point(54, 46)
        Me.label_JobResults_Accept.Name = "label_JobResults_Accept"
        Me.label_JobResults_Accept.Size = New System.Drawing.Size(148, 15)
        Me.label_JobResults_Accept.TabIndex = 28
        Me.label_JobResults_Accept.Text = "Accept:"
        '
        'textBox_JobN_TotalIterations
        '
        Me.textBox_JobN_TotalIterations.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textBox_JobN_TotalIterations.Location = New System.Drawing.Point(207, 22)
        Me.textBox_JobN_TotalIterations.Name = "textBox_JobN_TotalIterations"
        Me.textBox_JobN_TotalIterations.ReadOnly = True
        Me.textBox_JobN_TotalIterations.Size = New System.Drawing.Size(100, 21)
        Me.textBox_JobN_TotalIterations.TabIndex = 26
        Me.textBox_JobN_TotalIterations.Text = "textBox1"
        Me.textBox_JobN_TotalIterations.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'label_JobResults_TotalIterations
        '
        Me.label_JobResults_TotalIterations.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.label_JobResults_TotalIterations.Location = New System.Drawing.Point(24, 24)
        Me.label_JobResults_TotalIterations.Name = "label_JobResults_TotalIterations"
        Me.label_JobResults_TotalIterations.Size = New System.Drawing.Size(176, 15)
        Me.label_JobResults_TotalIterations.TabIndex = 25
        Me.label_JobResults_TotalIterations.Text = "Total Iterations:"
        '
        'label_ResultBar
        '
        Me.label_ResultBar.BackColor = System.Drawing.SystemColors.Control
        Me.label_ResultBar.Dock = System.Windows.Forms.DockStyle.Top
        Me.label_ResultBar.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label_ResultBar.Location = New System.Drawing.Point(3, 5)
        Me.label_ResultBar.Name = "label_ResultBar"
        Me.label_ResultBar.Size = New System.Drawing.Size(907, 27)
        Me.label_ResultBar.TabIndex = 25
        Me.label_ResultBar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnRun
        '
        Me.btnRun.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnRun.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRun.Location = New System.Drawing.Point(267, 58)
        Me.btnRun.Name = "btnRun"
        Me.btnRun.Size = New System.Drawing.Size(130, 35)
        Me.btnRun.TabIndex = 43
        Me.btnRun.Text = "Run Once"
        '
        'label_Online
        '
        Me.label_Online.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.label_Online.AutoSize = True
        Me.label_Online.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label_Online.Location = New System.Drawing.Point(279, 115)
        Me.label_Online.Name = "label_Online"
        Me.label_Online.Size = New System.Drawing.Size(119, 15)
        Me.label_Online.TabIndex = 51
        Me.label_Online.Text = "System online status"
        '
        'CogJobResultHistoryCollectionEdit1
        '
        Me.CogJobResultHistoryCollectionEdit1.AutoScroll = True
        Me.CogJobResultHistoryCollectionEdit1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.CogJobResultHistoryCollectionEdit1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.CogJobResultHistoryCollectionEdit1.Location = New System.Drawing.Point(0, 0)
        Me.CogJobResultHistoryCollectionEdit1.Name = "CogJobResultHistoryCollectionEdit1"
        Me.CogJobResultHistoryCollectionEdit1.SelectedIndex = -1
        Me.CogJobResultHistoryCollectionEdit1.SelectorControlHeight = 29
        Me.CogJobResultHistoryCollectionEdit1.Size = New System.Drawing.Size(503, 148)
        Me.CogJobResultHistoryCollectionEdit1.Subject = Nothing
        Me.CogJobResultHistoryCollectionEdit1.TabIndex = 0
        '
        'groupBox_DividerLine
        '
        Me.groupBox_DividerLine.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.groupBox_DividerLine.Location = New System.Drawing.Point(251, 10)
        Me.groupBox_DividerLine.Name = "groupBox_DividerLine"
        Me.groupBox_DividerLine.Size = New System.Drawing.Size(3, 88)
        Me.groupBox_DividerLine.TabIndex = 48
        Me.groupBox_DividerLine.TabStop = False
        '
        'applicationErrorProvider
        '
        Me.applicationErrorProvider.ContainerControl = Me
        '
        'label_Login
        '
        Me.label_Login.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.label_Login.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label_Login.Location = New System.Drawing.Point(13, 115)
        Me.label_Login.Name = "label_Login"
        Me.label_Login.Size = New System.Drawing.Size(106, 19)
        Me.label_Login.TabIndex = 49
        Me.label_Login.Text = "Current login:"
        '
        'button_Configuration
        '
        Me.button_Configuration.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.button_Configuration.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.button_Configuration.Location = New System.Drawing.Point(135, 25)
        Me.button_Configuration.Name = "button_Configuration"
        Me.button_Configuration.Size = New System.Drawing.Size(104, 28)
        Me.button_Configuration.TabIndex = 45
        Me.button_Configuration.Text = "Configuration..."
        '
        'comboBox_Login
        '
        Me.comboBox_Login.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.comboBox_Login.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboBox_Login.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.comboBox_Login.Location = New System.Drawing.Point(119, 112)
        Me.comboBox_Login.Name = "comboBox_Login"
        Me.comboBox_Login.Size = New System.Drawing.Size(132, 24)
        Me.comboBox_Login.TabIndex = 41
        '
        'button_SaveSettings
        '
        Me.button_SaveSettings.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.button_SaveSettings.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.button_SaveSettings.Location = New System.Drawing.Point(135, 61)
        Me.button_SaveSettings.Name = "button_SaveSettings"
        Me.button_SaveSettings.Size = New System.Drawing.Size(104, 28)
        Me.button_SaveSettings.TabIndex = 47
        Me.button_SaveSettings.Text = "Save Settings..."
        '
        'panel3
        '
        Me.panel3.Controls.Add(Me.panel4)
        Me.panel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panel3.Location = New System.Drawing.Point(0, 153)
        Me.panel3.Name = "panel3"
        Me.panel3.Size = New System.Drawing.Size(913, 490)
        Me.panel3.TabIndex = 40
        '
        'splitter1
        '
        Me.splitter1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.splitter1.Dock = System.Windows.Forms.DockStyle.Top
        Me.splitter1.Location = New System.Drawing.Point(0, 148)
        Me.splitter1.Name = "splitter1"
        Me.splitter1.Size = New System.Drawing.Size(913, 5)
        Me.splitter1.TabIndex = 41
        Me.splitter1.TabStop = False
        '
        'checkBox_LiveDisplay
        '
        Me.checkBox_LiveDisplay.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.checkBox_LiveDisplay.Appearance = System.Windows.Forms.Appearance.Button
        Me.checkBox_LiveDisplay.Location = New System.Drawing.Point(23, 61)
        Me.checkBox_LiveDisplay.Name = "checkBox_LiveDisplay"
        Me.checkBox_LiveDisplay.Size = New System.Drawing.Size(104, 28)
        Me.checkBox_LiveDisplay.TabIndex = 46
        Me.checkBox_LiveDisplay.Text = "Live Image"
        Me.checkBox_LiveDisplay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'button_About
        '
        Me.button_About.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.button_About.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.button_About.Location = New System.Drawing.Point(23, 25)
        Me.button_About.Name = "button_About"
        Me.button_About.Size = New System.Drawing.Size(104, 28)
        Me.button_About.TabIndex = 44
        Me.button_About.Text = "About..."
        '
        'btnRunCont
        '
        Me.btnRunCont.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnRunCont.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRunCont.Location = New System.Drawing.Point(266, 16)
        Me.btnRunCont.Name = "btnRunCont"
        Me.btnRunCont.Size = New System.Drawing.Size(130, 37)
        Me.btnRunCont.TabIndex = 42
        Me.btnRunCont.Text = "Run Continuously"
        '
        'panel1
        '
        Me.panel1.Controls.Add(Me.Panel7)
        Me.panel1.Controls.Add(Me.Panel2)
        Me.panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.panel1.Location = New System.Drawing.Point(0, 0)
        Me.panel1.Name = "panel1"
        Me.panel1.Size = New System.Drawing.Size(913, 148)
        Me.panel1.TabIndex = 39
        '
        'Panel7
        '
        Me.Panel7.Controls.Add(Me.CogJobResultHistoryCollectionEdit1)
        Me.Panel7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel7.Location = New System.Drawing.Point(0, 0)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(503, 148)
        Me.Panel7.TabIndex = 53
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.button_SaveSettings)
        Me.Panel2.Controls.Add(Me.label_Online)
        Me.Panel2.Controls.Add(Me.btnRun)
        Me.Panel2.Controls.Add(Me.label_Login)
        Me.Panel2.Controls.Add(Me.btnRunCont)
        Me.Panel2.Controls.Add(Me.comboBox_Login)
        Me.Panel2.Controls.Add(Me.button_Configuration)
        Me.Panel2.Controls.Add(Me.groupBox_DividerLine)
        Me.Panel2.Controls.Add(Me.checkBox_LiveDisplay)
        Me.Panel2.Controls.Add(Me.button_About)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel2.Location = New System.Drawing.Point(503, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(410, 148)
        Me.Panel2.TabIndex = 52
        '
        'VisionControl
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.panel3)
        Me.Controls.Add(Me.splitter1)
        Me.Controls.Add(Me.panel1)
        Me.Name = "VisionControl"
        Me.Size = New System.Drawing.Size(913, 643)
        CType(Me.pictureBox_Logo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panel4.ResumeLayout(False)
        Me.panel5.ResumeLayout(False)
        Me.panel6.ResumeLayout(False)
        Me.tabControl_JobTabs.ResumeLayout(False)
        Me.tabPage_JobN_JobStatistics.ResumeLayout(False)
        Me.groupBox_AcquisitionResults.ResumeLayout(False)
        Me.groupBox_AcquisitionResults.PerformLayout()
        Me.groupBox_JobThroughput.ResumeLayout(False)
        Me.groupBox_JobThroughput.PerformLayout()
        Me.groupBox_JobResults.ResumeLayout(False)
        Me.groupBox_JobResults.PerformLayout()
        CType(Me.applicationErrorProvider, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panel3.ResumeLayout(False)
        Me.panel1.ResumeLayout(False)
        Me.Panel7.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    '///////////////////////// START WIZARD GENERATED
    ' cognex.wizard.controldeclarations.begin
    Friend WithEvents tabPage_Job0_CogJob1 As TabPage
    ' cognex.wizard.controldeclarations.end
    '///////////////////////// END WIZARD GENERATED

    Private WithEvents label_controlErrorMessage As System.Windows.Forms.Label
    Private WithEvents pictureBox_Logo As System.Windows.Forms.PictureBox
    Private WithEvents panel4 As System.Windows.Forms.Panel
    Private WithEvents panel5 As System.Windows.Forms.Panel
    Friend WithEvents CogRecordsDisplay1 As Cognex.VisionPro.CogRecordsDisplay
    Private WithEvents splitter2 As System.Windows.Forms.Splitter
    Private WithEvents panel6 As System.Windows.Forms.Panel
    Private WithEvents tabControl_JobTabs As System.Windows.Forms.TabControl
    Private WithEvents tabPage_JobN_JobStatistics As System.Windows.Forms.TabPage
    Private WithEvents button_ResetStatistics As System.Windows.Forms.Button
    Private WithEvents button_ResetStatisticsForAllJobs As System.Windows.Forms.Button
    Private WithEvents groupBox_AcquisitionResults As System.Windows.Forms.GroupBox
    Private WithEvents textBox_JobN_TotalAcquisitionOverruns As System.Windows.Forms.TextBox
    Private WithEvents label_AcquisitionResults_Overruns As System.Windows.Forms.Label
    Private WithEvents textBox_JobN_TotalAcquisitionErrors As System.Windows.Forms.TextBox
    Private WithEvents label_AcquisitionResults_Errors As System.Windows.Forms.Label
    Private WithEvents textBox_JobN_TotalAcquisitions As System.Windows.Forms.TextBox
    Private WithEvents label_AcquisitionResults_TotalAcquisitions As System.Windows.Forms.Label
    Private WithEvents groupBox_JobThroughput As System.Windows.Forms.GroupBox
    Private WithEvents label_JobThroughput_persec As System.Windows.Forms.Label
    Private WithEvents textBox_JobN_MaxThroughput As System.Windows.Forms.TextBox
    Private WithEvents textBox_JobN_MinThroughput As System.Windows.Forms.TextBox
    Private WithEvents label_JobThroughput_Max As System.Windows.Forms.Label
    Private WithEvents label_JobThroughput_Min As System.Windows.Forms.Label
    Private WithEvents textBox_JobN_Throughput As System.Windows.Forms.TextBox
    Private WithEvents label_JobThroughput_TotalThroughput As System.Windows.Forms.Label
    Private WithEvents groupBox_JobResults As System.Windows.Forms.GroupBox
    Private WithEvents label_JobResults_Percent As System.Windows.Forms.Label
    Private WithEvents textBox_JobN_TotalAccept_Percent As System.Windows.Forms.TextBox
    Private WithEvents textBox_JobN_TotalWarning As System.Windows.Forms.TextBox
    Private WithEvents textBox_JobN_TotalError As System.Windows.Forms.TextBox
    Private WithEvents label_JobResults_Error As System.Windows.Forms.Label
    Private WithEvents label_JobResults_Warning As System.Windows.Forms.Label
    Private WithEvents textBox_JobN_TotalReject As System.Windows.Forms.TextBox
    Private WithEvents label_JobResults_Reject As System.Windows.Forms.Label
    Private WithEvents textBox_JobN_TotalAccept As System.Windows.Forms.TextBox
    Private WithEvents label_JobResults_Accept As System.Windows.Forms.Label
    Private WithEvents textBox_JobN_TotalIterations As System.Windows.Forms.TextBox
    Private WithEvents label_JobResults_TotalIterations As System.Windows.Forms.Label
    Private WithEvents label_ResultBar As System.Windows.Forms.Label
    Private WithEvents btnRun As System.Windows.Forms.Button
    Private WithEvents label_Online As System.Windows.Forms.Label
    Friend WithEvents CogJobResultHistoryCollectionEdit1 As Cognex.VisionPro.QuickBuild.CogJobResultHistoryCollectionEdit
    Private WithEvents groupBox_DividerLine As System.Windows.Forms.GroupBox
    Private WithEvents applicationErrorProvider As System.Windows.Forms.ErrorProvider
    Private WithEvents panel3 As System.Windows.Forms.Panel
    Private WithEvents splitter1 As System.Windows.Forms.Splitter
    Private WithEvents panel1 As System.Windows.Forms.Panel
    Private WithEvents label_Login As System.Windows.Forms.Label
    Private WithEvents comboBox_Login As System.Windows.Forms.ComboBox
    Private WithEvents button_SaveSettings As System.Windows.Forms.Button
    Private WithEvents checkBox_LiveDisplay As System.Windows.Forms.CheckBox
    Private WithEvents button_About As System.Windows.Forms.Button
    Private WithEvents button_Configuration As System.Windows.Forms.Button
    Private WithEvents btnRunCont As System.Windows.Forms.Button
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel

End Class
