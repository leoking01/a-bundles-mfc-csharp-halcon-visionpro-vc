Imports System
Imports System.IO

Public Class OptionsFile
  Private _fname As String
  Private _enableImageDisplay As Boolean
  Private _enableIOAtStartup As Boolean
  Private _changed As Boolean

  Public Sub New()
      ' write options file into current executable directory
      _fname = Utility.GetThisExecutableDirectory() + "options.txt"

      ' defaults
      _enableImageDisplay = True
      _enableIOAtStartup = True

      _changed = False
  End Sub

  Public ReadOnly Property FileName() As String
      Get
        Return _fname
      End Get
  End Property

  Public Property Changed() As Boolean
      Get
        Return _changed
      End Get
      Set(ByVal Value As Boolean)
        _changed = Value
      End Set
  End Property

  Public Property EnableImageDisplay() As Boolean
      Get
        Return _enableImageDisplay
      End Get
      Set(ByVal Value As Boolean)
        If Not _enableImageDisplay = Value Then
          _enableImageDisplay = Value
          _changed = True
        End If
      End Set
  End Property

    Public Property EnableIOAtStartup() As Boolean
        Get
            Return _enableIOAtStartup
        End Get
        Set(ByVal Value As Boolean)
            If Not _enableIOAtStartup = Value Then
                _enableIOAtStartup = Value
                _changed = True
            End If
        End Set
    End Property

  Public Function Read() As Boolean
      ' return false if file does not exist
      If (Not File.Exists(_fname)) Then
        Return False
      End If

      ' open and read file
      Dim line As String = Nothing
      Dim sr As StreamReader
      Try
        sr = New StreamReader(_fname)
      Catch ex As Exception
        Return False
      End Try

      Try
        While (Not (line = sr.ReadLine()) = Nothing)
            ' ignore blank lines and lines that begin with #
            line = line.Trim()
            If (line.Length = 0 Or line.Chars(0) = "#"c) Then
            Else

              ' parse line into "name = value" - ignore lines that do not fit that format
              Dim parts As String() = line.Split(New Char() {"="}, 2)
              If (Not parts.Length = 2) Then
              Else
                parts(0) = parts(0).Trim()
                parts(1) = parts(1).Trim()

                ParseNameValue(parts(0), parts(1))
              End If
            End If
        End While
      Catch ex As Exception
        Return False
      Finally
        sr.Close()
      End Try

      Return True
  End Function

  Public Sub Write()
      ' don't write if nothing has changed
      If (Not _changed) Then
        Return
      End If

      Dim fileContents As String = ""
      fileContents += "# Application options" + Environment.NewLine
      fileContents += Environment.NewLine

      fileContents += "EnableImageDisplay = " + _enableImageDisplay.ToString() + Environment.NewLine
      fileContents += "EnableIOAtStartup = " + _enableIOAtStartup.ToString() + Environment.NewLine

      Dim sw As StreamWriter = New StreamWriter(_fname)
      Try
        sw.Write(fileContents)
        _changed = False
      Finally
        sw.Close()
      End Try
  End Sub

  Private Sub ParseNameValue(ByVal name As String, ByVal value As String)
      Try
        Select Case name
          Case "EnableImageDisplay"
            EnableImageDisplay = Boolean.Parse(value)
          Case "EnableIOAtStartup"
            EnableIOAtStartup = Boolean.Parse(value)
        End Select
      Catch
      End Try
  End Sub

End Class
