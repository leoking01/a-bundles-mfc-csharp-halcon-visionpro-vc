Partial Class VisionControl

    '///////////////////////// START WIZARD GENERATED
    ' cognex.wizard.globals.begin
    Private Shared mVppFilename As String = "../../../QuickBuild1-openAnImage.vpp"
    'Private Shared mApplicationName As String = "QuickBuild1-openAnImage"
    Private Shared mApplicationName As String = "QA"
    Private Shared mUsePasswords As Boolean = False
    Private Shared mQuickBuildAccess As Boolean = True
    Private Shared mDefaultAdministratorPassword As String = ""
    Private Shared mDefaultSupervisorPassword As String = ""
    Private Shared mGenerationDateTime As DateTime = New DateTime(2019,4,20,5,47,22)
    Private Shared mGeneratedByVersion As String = "53.2.0.0"
    ' cognex.wizard.globals.end
    '///////////////////////// END WIZARD GENERATED

    Private Sub Wizard_FormLoad()
      '///////////////////////// START WIZARD GENERATED
      ' cognex.wizard.formloadactions
      '///////////////////////// END WIZARD GENERATED
    End Sub

    Private Sub Wizard_AttachPropertyProviders()
      '///////////////////////// START WIZARD GENERATED
      ' cognex.wizard.attachpropertyproviders
      '///////////////////////// END WIZARD GENERATED
    End Sub

    Private Sub Wizard_DetachPropertyProviders()
      '///////////////////////// START WIZARD GENERATED
      ' cognex.wizard.detachpropertyproviders
      '///////////////////////// END WIZARD GENERATED
    End Sub

    Private Sub Wizard_EnableControls(ByVal running As Boolean)
      '///////////////////////// START WIZARD GENERATED
      ' cognex.wizard.enablecontrols
      '///////////////////////// END WIZARD GENERATED
    End Sub

    Private Sub Wizard_AddJobTabs(ByVal newPagesList As System.Collections.ArrayList)
      '///////////////////////// START WIZARD GENERATED
      ' begin cognex.wizard.addjobtabs
      select mSelectedJob
        case 0
          newPagesList.Add(tabPage_Job0_CogJob1)
      end select
      ' end cognex.wizard.addjobtabs
      '///////////////////////// END WIZARD GENERATED
    End Sub

    Private Sub Wizard_UpdateJobResults(ByVal idx As Integer, ByVal result As Cognex.VisionPro.ICogRecord)
      '///////////////////////// START WIZARD GENERATED
      ' begin cognex.wizard.updatejobresults
      ' end cognex.wizard.updatejobresults
      '///////////////////////// END WIZARD GENERATED
    End Sub

End Class
