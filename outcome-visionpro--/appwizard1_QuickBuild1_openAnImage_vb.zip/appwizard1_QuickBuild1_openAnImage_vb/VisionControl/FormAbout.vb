Imports System.IO

Public Class FormAbout
    Inherits System.Windows.Forms.Form

  Private mAboutFilename As String
  Private mVisionControl As VisionControl

#Region " Windows Form Designer generated code "

    Public Sub New(ByVal fname As String, ByVal ctl As VisionControl)
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        mAboutFilename = fname
        mVisionControl = ctl

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
Friend WithEvents groupBox1 As System.Windows.Forms.GroupBox
Friend WithEvents textBox_AboutFile As System.Windows.Forms.TextBox
Friend WithEvents label_About As System.Windows.Forms.Label
Friend WithEvents textBox_AppInfo As System.Windows.Forms.TextBox
Friend WithEvents textBox_PasswordFile As System.Windows.Forms.TextBox
Friend WithEvents label_Password As System.Windows.Forms.Label
Friend WithEvents textBox_VppFilename As System.Windows.Forms.TextBox
Friend WithEvents label_Vpp As System.Windows.Forms.Label
Friend WithEvents button_OK As System.Windows.Forms.Button
Friend WithEvents textBox_aboutText As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
Me.groupBox1 = New System.Windows.Forms.GroupBox
Me.textBox_AboutFile = New System.Windows.Forms.TextBox
Me.label_About = New System.Windows.Forms.Label
Me.textBox_AppInfo = New System.Windows.Forms.TextBox
Me.textBox_PasswordFile = New System.Windows.Forms.TextBox
Me.label_Password = New System.Windows.Forms.Label
Me.textBox_VppFilename = New System.Windows.Forms.TextBox
Me.label_Vpp = New System.Windows.Forms.Label
Me.button_OK = New System.Windows.Forms.Button
Me.textBox_aboutText = New System.Windows.Forms.TextBox
Me.groupBox1.SuspendLayout()
Me.SuspendLayout()
'
'groupBox1
'
Me.groupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
Me.groupBox1.Controls.Add(Me.textBox_AboutFile)
Me.groupBox1.Controls.Add(Me.label_About)
Me.groupBox1.Controls.Add(Me.textBox_AppInfo)
Me.groupBox1.Controls.Add(Me.textBox_PasswordFile)
Me.groupBox1.Controls.Add(Me.label_Password)
Me.groupBox1.Controls.Add(Me.textBox_VppFilename)
Me.groupBox1.Controls.Add(Me.label_Vpp)
Me.groupBox1.Location = New System.Drawing.Point(16, 16)
Me.groupBox1.Name = "groupBox1"
Me.groupBox1.Size = New System.Drawing.Size(536, 168)
Me.groupBox1.TabIndex = 4
Me.groupBox1.TabStop = False
'
'textBox_AboutFile
'
Me.textBox_AboutFile.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
Me.textBox_AboutFile.Location = New System.Drawing.Point(152, 128)
Me.textBox_AboutFile.Name = "textBox_AboutFile"
Me.textBox_AboutFile.ReadOnly = True
Me.textBox_AboutFile.Size = New System.Drawing.Size(360, 20)
Me.textBox_AboutFile.TabIndex = 3
Me.textBox_AboutFile.Text = "textBox1"
'
'label_About
'
Me.label_About.Location = New System.Drawing.Point(24, 128)
Me.label_About.Name = "label_About"
Me.label_About.Size = New System.Drawing.Size(128, 16)
Me.label_About.TabIndex = 5
Me.label_About.Text = "Using about.txt file:"
'
'textBox_AppInfo
'
Me.textBox_AppInfo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
Me.textBox_AppInfo.Location = New System.Drawing.Point(24, 24)
Me.textBox_AppInfo.Multiline = True
Me.textBox_AppInfo.Name = "textBox_AppInfo"
Me.textBox_AppInfo.ReadOnly = True
Me.textBox_AppInfo.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
Me.textBox_AppInfo.Size = New System.Drawing.Size(488, 40)
Me.textBox_AppInfo.TabIndex = 0
Me.textBox_AppInfo.Text = "textBox"
'
'textBox_PasswordFile
'
Me.textBox_PasswordFile.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
Me.textBox_PasswordFile.Location = New System.Drawing.Point(152, 104)
Me.textBox_PasswordFile.Name = "textBox_PasswordFile"
Me.textBox_PasswordFile.ReadOnly = True
Me.textBox_PasswordFile.Size = New System.Drawing.Size(360, 20)
Me.textBox_PasswordFile.TabIndex = 2
Me.textBox_PasswordFile.Text = "textBox1"
'
'label_Password
'
Me.label_Password.Location = New System.Drawing.Point(24, 104)
Me.label_Password.Name = "label_Password"
Me.label_Password.Size = New System.Drawing.Size(128, 16)
Me.label_Password.TabIndex = 2
Me.label_Password.Text = "Using password file:"
'
'textBox_VppFilename
'
Me.textBox_VppFilename.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
Me.textBox_VppFilename.Location = New System.Drawing.Point(152, 80)
Me.textBox_VppFilename.Name = "textBox_VppFilename"
Me.textBox_VppFilename.ReadOnly = True
Me.textBox_VppFilename.Size = New System.Drawing.Size(360, 20)
Me.textBox_VppFilename.TabIndex = 1
Me.textBox_VppFilename.Text = "textBox1"
'
'label_Vpp
'
Me.label_Vpp.Location = New System.Drawing.Point(24, 80)
Me.label_Vpp.Name = "label_Vpp"
Me.label_Vpp.Size = New System.Drawing.Size(128, 16)
Me.label_Vpp.TabIndex = 0
Me.label_Vpp.Text = "Using .vpp file:"
'
'button_OK
'
Me.button_OK.Anchor = System.Windows.Forms.AnchorStyles.Bottom
Me.button_OK.DialogResult = System.Windows.Forms.DialogResult.OK
Me.button_OK.Location = New System.Drawing.Point(224, 360)
Me.button_OK.Name = "button_OK"
Me.button_OK.Size = New System.Drawing.Size(104, 24)
Me.button_OK.TabIndex = 3
Me.button_OK.Text = "OK"
'
'textBox_aboutText
'
Me.textBox_aboutText.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
Me.textBox_aboutText.Location = New System.Drawing.Point(16, 200)
Me.textBox_aboutText.Multiline = True
Me.textBox_aboutText.Name = "textBox_aboutText"
Me.textBox_aboutText.ReadOnly = True
Me.textBox_aboutText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
Me.textBox_aboutText.Size = New System.Drawing.Size(536, 152)
Me.textBox_aboutText.TabIndex = 5
Me.textBox_aboutText.Text = "textBox1"
'
'FormAbout
'
Me.AcceptButton = Me.button_OK
Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
Me.CancelButton = Me.button_OK
Me.ClientSize = New System.Drawing.Size(568, 398)
Me.Controls.Add(Me.groupBox1)
Me.Controls.Add(Me.button_OK)
Me.Controls.Add(Me.textBox_aboutText)
Me.Name = "FormAbout"
Me.Text = "FormAbout"
Me.groupBox1.ResumeLayout(False)
Me.ResumeLayout(False)

    End Sub

#End Region

Private Sub FormAbout_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
  label_About.Text = ResourceUtility.GetString("RtUsingAbout")
  label_Password.Text = ResourceUtility.GetString("RtUsingPasswords")
  label_Vpp.Text = ResourceUtility.GetString("RtUsingVpp")
  button_OK.Text = ResourceUtility.GetString("RtOK")

  ' general info
  textBox_AppInfo.Text = ResourceUtility.FormatString("RtAppGeneratedInfo", VisionControl.GenerationDateTime.ToString("r"), VisionControl.GeneratedByVersion)

  ' vpp filename
  textBox_VppFilename.Text = mVisionControl.LoadedVppFilename

  ' password info
  If (mVisionControl.UsingPasswords()) Then
    If (mVisionControl.CurrentPasswordFile.PasswordFileValid) Then
      textBox_PasswordFile.Text = mVisionControl.CurrentPasswordFile.PasswordFilename
    Else
      textBox_PasswordFile.Text = ResourceUtility.GetString("RtDefaultPasswords")
    End If
  Else
    textBox_PasswordFile.Text = ResourceUtility.GetString("RtNoFile")
  End If

  Dim aboutText As String = ""

  If (Not File.Exists(mAboutFilename)) Then
        aboutText = ResourceUtility.GetString("RtNoDetails")
        textBox_AboutFile.Text = ResourceUtility.GetString("RtNoFile")
  Else
    ' open and read file
    textBox_AboutFile.Text = mAboutFilename
    Try
      If (Not mAboutFilename Is Nothing) Then
        Dim sr As StreamReader = New StreamReader(mAboutFilename)
        aboutText = sr.ReadToEnd()
        sr.Close()
      End If
    Catch exc As Exception
      aboutText = ResourceUtility.FormatString("RtOpenFileError", mAboutFilename) + System.Environment.NewLine + System.Environment.NewLine
      aboutText += exc.ToString()
    End Try
  End If

  ' display contents
  textBox_aboutText.Text = aboutText

End Sub

End Class
