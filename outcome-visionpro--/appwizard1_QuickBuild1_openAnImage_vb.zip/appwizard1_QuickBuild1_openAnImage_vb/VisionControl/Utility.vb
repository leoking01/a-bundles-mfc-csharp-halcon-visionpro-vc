Imports System

Imports Cognex.VisionPro
Imports Cognex.VisionPro.Implementation.Internal
Imports Cognex.VisionPro.QuickBuild
Imports System.Resources
Imports System.Reflection
Public Class Utility

  Public Shared Function TraverseSubRecords(ByVal r As Cognex.VisionPro.ICogRecord, ByVal subs As String()) As Cognex.VisionPro.ICogRecord
    ' Utility function to walk down to a specific subrecord
    If (r Is Nothing) Then
      Return r
    End If

    Dim s As String
    For Each s In subs
      If (r.SubRecords.ContainsKey(s)) Then
        r = r.SubRecords(s)
      Else
        Return Nothing
      End If
    Next s

    Return r
  End Function

  Public Shared Sub FlushAllQueues(ByVal jm As CogJobManager)
    ' Flush all queues
    jm.UserQueueFlush()
    jm.FailureQueueFlush()
    Dim i As Integer
    For i = 0 To jm.JobCount - 1
      jm.Job(i).OwnedIndependent.RealTimeQueueFlush()
      jm.Job(i).ImageQueueFlush()
    Next i
  End Sub

  Public Shared Function GetJobIndexFromName(ByVal mgr As CogJobManager, ByVal name As String) As Integer
    Dim i As Integer
    For i = 0 To mgr.JobCount - 1
      If (mgr.Job(i).Name = name) Then
        Return i
      End If
    Next i
    Return -1
  End Function

  Public Shared Function AddRecordToDisplay(ByVal disp As CogRecordsDisplay, ByVal r As Cognex.VisionPro.ICogRecord, ByVal subs As String(), ByVal pickBestImage As Boolean) As Boolean
    ' Utility function to put a specific subrecord into a display
    Dim addrec As Cognex.VisionPro.ICogRecord = Utility.TraverseSubRecords(r, subs)
    If (Not addrec Is Nothing) Then
      ' if this is the first record in, then always select an image
      If (disp.Subject Is Nothing) Then
        pickBestImage = True
      End If

      disp.Subject = addrec

      If (pickBestImage) Then
        '  // select first non-empty image record, to workaround the fact that the input image tool
        '  // adds an empty subrecord to the LastRun record when it is disabled (when an image file
        '  // tool is used, for example)
        Dim i As Integer
        For i = 0 To addrec.SubRecords.Count - 1
          Dim img As Cognex.VisionPro.ICogImage = Nothing
          Try
            img = CType(addrec.SubRecords(i).Content, Cognex.VisionPro.ICogImage)
          Catch
            img = Nothing
          End Try
          If ((Not img Is Nothing) AndAlso (Not img.Height = 0) AndAlso (Not img.Width = 0)) Then
            disp.SelectedRecordKey = addrec.RecordKey & "." & addrec.SubRecords(i).RecordKey
            Exit For
          End If
        Next i
      End If

      Return True
    End If

    Return False
  End Function

  Private Shared Function TypeIsNumeric(ByVal t As Type) As Boolean
    If (t Is Nothing) Then
      Return False
    End If

    If (t Is GetType(Double) Or t Is GetType(Long) Or _
        t Is GetType(Byte) Or _
        t Is GetType(Short) Or _
        t Is GetType(Integer) Or _
        t Is GetType(Decimal) Or _
        t Is GetType(Single)) Then
      Return True
    End If

    Return False
  End Function

  Private Shared Function GetPropertyType(ByVal obj As Object, ByVal path As String) As Type
    If (obj Is Nothing Or path = "") Then
      Return Nothing
    End If

    Dim infos As System.Reflection.MemberInfo() = CogToolTerminals.ConvertPathToMemberInfos(obj, obj.GetType(), path)

    If (infos.Length = 0) Then
      Return Nothing
    End If

    ' Return the type of the last path element.
    Return CogToolTerminals.GetReturnType(infos(infos.Length - 1))
  End Function

  Public Shared Sub FillUserResultData(ByVal ctrl As Control, ByVal result As Cognex.VisionPro.ICogRecord, ByVal path As String)
    FillUserResultData(ctrl, result, path, False)
  End Sub

  Public Shared Sub FillUserResultData(ByVal ctrl As Control, ByVal result As Cognex.VisionPro.ICogRecord, ByVal path As String, ByVal convertRadiansToDegrees As Boolean)
    ' Extract the data identified by the path (if available) from the given result record.
    ' Use a format string for doubles.
    Dim rtn As String
    Dim align As HorizontalAlignment = HorizontalAlignment.Left
    If (result Is Nothing) Then
      rtn = ResourceUtility.GetString("RtResultNotAvailable")
    Else
      Dim obj As Object = Nothing

      Try
        obj = result.SubRecords(path).Content
      Catch
      End Try

      ' check if data is available
       If (Not obj Is Nothing AndAlso Not obj.GetType().FullName = "System.Object") Then
         If (obj.GetType() Is GetType(Double)) Then
           Dim d As Double = CType(obj, Double)
           If (convertRadiansToDegrees) Then
             d = CogMisc.RadToDeg(d)
           End If
           rtn = (d.ToString("0.000"))
         Else
           rtn = obj.ToString()
         End If

         If (TypeIsNumeric(obj.GetType())) Then
           align = HorizontalAlignment.Right
         End If

       Else
         rtn = ResourceUtility.GetString("RtResultNotAvailable")
       End If
    End If

    ctrl.Text = rtn

    Dim box As TextBox = Nothing
    Try
      box = CType(ctrl, TextBox)
    Catch
    End Try

    If (Not box Is Nothing) Then
        box.TextAlign = align
    End If
  End Sub

  Public Shared Sub SetupPropertyProvider(ByVal p As CogToolPropertyProvider, ByVal gui As Control, ByVal tool As Object, ByVal path As String)
    p.SetPath(gui, path)

    Dim box As TextBox = Nothing
    Try
      box = CType(gui, TextBox)
    Catch
    End Try

    If (Not box Is Nothing) Then
      Dim t As Type = GetPropertyType(tool, path)
      If (TypeIsNumeric(t)) Then
        box.TextAlign = HorizontalAlignment.Right
      End If
    End If
  End Sub

  Public Shared Function GetThisExecutableDirectory() As String
    Dim assm As System.Reflection.Assembly = System.Reflection.Assembly.GetExecutingAssembly()
    Dim loc As String = assm.Location
    loc = System.IO.Path.GetDirectoryName(loc) + "\"
    Return loc
  End Function

Public Shared Function AccessAllowed(ByVal stringLevelRequired As String, ByVal currentLogin As AccessLevel) As Boolean
  ' return true if the currentLogin is equal to or greater than the given access
  ' level (expressed as a string)
  Dim needed As AccessLevel = AccessLevel.Administrator

  Try
    Dim obj As Object = [Enum].Parse(GetType(AccessLevel), stringLevelRequired, True)
    needed = CType(obj, AccessLevel)
  Catch
  End Try

  Return currentLogin >= needed
End Function

''' <summary>
''' Take a filename (generally a relative path) and determine the full path to the file to
''' use.  First the directory containing the current .vpp file is checked for the given filename,
''' then the directory containing this code's assembly is checked.
''' </summary>
Public Shared Function ResolveAssociatedFilename(ByVal vppfname As String, ByVal fname As String) As String
  ' check for the given file in the same directory as the developer vpp file path
  Dim trydev As String = System.IO.Path.GetDirectoryName(vppfname) + "\\" + fname
  If (System.IO.File.Exists(trydev)) Then
    fname = trydev
  Else
    ' otherwise use same directory as this executable
    fname = GetThisExecutableDirectory() + fname
  End If

  Return fname
End Function

 End Class

Public Class ResourceUtility
  ' helper class to wrap string resources for this application

  Private Shared mResources As ResourceManager = Nothing

  Shared Sub New()
    mResources = New ResourceManager("VisionControl.strings", [Assembly].GetExecutingAssembly())
  End Sub

  Public Shared Function GetString(ByVal resname As String) As String
    Dim str As String = Nothing
    Try
      str = mResources.GetString(resname)
    Catch
    End Try
    If (str = Nothing) Then
      str = "ERROR(" + resname + ")"
    End If
    Return str
  End Function

  Public Shared Function FormatString(ByVal resname As String, ByVal arg0 As String) As String
    Try
      Return String.Format(GetString(resname), arg0)
    Catch
    End Try
    Return "ERROR(" + resname + ")"
  End Function

  Public Shared Function FormatString(ByVal resname As String, ByVal arg0 As String, ByVal arg1 As String) As String
    Try
      Return String.Format(GetString(resname), arg0, arg1)
    Catch
    End Try
    Return "ERROR(" + resname + ")"
  End Function

End Class
