Public Enum FormConfigResult
  None
  QuickBuild
  SetPasswords
  AppOptions
End Enum

Public Class FormConfig
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New(ByVal enableQB As Boolean, ByVal enablePass As Boolean)
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        mEnablePasswordButton = enablePass
        mEnableQuickbuildButton = enableQB

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
Friend WithEvents button_SetPasswords As System.Windows.Forms.Button
Friend WithEvents button_QuickBuild As System.Windows.Forms.Button
Friend WithEvents button_AppOptions As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
Me.button_SetPasswords = New System.Windows.Forms.Button
Me.button_QuickBuild = New System.Windows.Forms.Button
Me.button_AppOptions = New System.Windows.Forms.Button
Me.SuspendLayout()
'
'button_SetPasswords
'
Me.button_SetPasswords.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
Me.button_SetPasswords.Location = New System.Drawing.Point(56, 96)
Me.button_SetPasswords.Name = "button_SetPasswords"
Me.button_SetPasswords.Size = New System.Drawing.Size(145, 30)
Me.button_SetPasswords.TabIndex = 3
Me.button_SetPasswords.Text = "Set Passwords..."
'
'button_QuickBuild
'
Me.button_QuickBuild.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
Me.button_QuickBuild.Location = New System.Drawing.Point(56, 19)
Me.button_QuickBuild.Name = "button_QuickBuild"
Me.button_QuickBuild.Size = New System.Drawing.Size(145, 30)
Me.button_QuickBuild.TabIndex = 2
Me.button_QuickBuild.Text = "QuickBuild..."
'
'button_AppOptions
'
Me.button_AppOptions.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
Me.button_AppOptions.Location = New System.Drawing.Point(56, 56)
Me.button_AppOptions.Name = "button_AppOptions"
Me.button_AppOptions.Size = New System.Drawing.Size(145, 30)
Me.button_AppOptions.TabIndex = 4
Me.button_AppOptions.Text = "Application Options..."
'
'FormConfig
'
Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
Me.ClientSize = New System.Drawing.Size(254, 144)
Me.Controls.Add(Me.button_AppOptions)
Me.Controls.Add(Me.button_SetPasswords)
Me.Controls.Add(Me.button_QuickBuild)
Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
Me.Name = "FormConfig"
Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
Me.Text = "FormConfig"
Me.ResumeLayout(False)

    End Sub

#End Region

  Private mConfigResult As FormConfigResult = FormConfigResult.None
  Private mEnablePasswordButton As Boolean = False
  Private mEnableQuickbuildButton As Boolean = False

  Public ReadOnly Property Result() As FormConfigResult
    Get
      Return mConfigResult
    End Get
  End Property

Private Sub button_QuickBuild_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button_QuickBuild.Click
  mConfigResult = FormConfigResult.QuickBuild
  Me.Close()
End Sub

Private Sub button_SetPasswords_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button_SetPasswords.Click
  mConfigResult = FormConfigResult.SetPasswords
  Me.Close()
End Sub

Private Sub FormConfig_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
  Me.Text = ResourceUtility.GetString("RtConfigurationTitle")
  button_QuickBuild.Text = ResourceUtility.GetString("RtQuickBuild")
  button_SetPasswords.Text = ResourceUtility.GetString("RtSetPasswords")

  button_QuickBuild.Enabled = mEnableQuickbuildButton
  button_SetPasswords.Enabled = mEnablePasswordButton
End Sub

Private Sub button_AppOptions_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button_AppOptions.Click
  mConfigResult = FormConfigResult.AppOptions
  Me.Close()
End Sub
End Class
