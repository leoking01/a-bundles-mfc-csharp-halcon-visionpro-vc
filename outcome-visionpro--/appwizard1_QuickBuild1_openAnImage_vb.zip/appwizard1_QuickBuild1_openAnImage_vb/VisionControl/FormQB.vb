Imports Cognex.VisionPro
Imports Cognex.VisionPro.QuickBuild

Public Class FormQB
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New(ByVal jm As CogJobManager)
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        mJM = jm

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
Friend WithEvents cogJobManagerEdit1 As Cognex.VisionPro.QuickBuild.CogJobManagerEdit
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
Me.cogJobManagerEdit1 = New Cognex.VisionPro.QuickBuild.CogJobManagerEdit
Me.SuspendLayout()
'
'cogJobManagerEdit1
'
Me.cogJobManagerEdit1.Dock = System.Windows.Forms.DockStyle.Fill
Me.cogJobManagerEdit1.Location = New System.Drawing.Point(0, 0)
Me.cogJobManagerEdit1.Name = "cogJobManagerEdit1"
Me.cogJobManagerEdit1.Size = New System.Drawing.Size(728, 454)
Me.cogJobManagerEdit1.Subject = Nothing
Me.cogJobManagerEdit1.TabIndex = 1
'
'FormQB
'
Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
Me.ClientSize = New System.Drawing.Size(728, 454)
Me.Controls.Add(Me.cogJobManagerEdit1)
Me.Name = "FormQB"
Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
Me.Text = "FormQB"
Me.ResumeLayout(False)

    End Sub

#End Region

  Private mJM As CogJobManager = Nothing

  Private Sub FormQB_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
    Me.Text = ResourceUtility.GetString("RtQuickBuildTitle")
    cogJobManagerEdit1.Subject = mJM
  End Sub

  Private Sub FormQB_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
      cogJobManagerEdit1.Subject = Nothing
  End Sub

End Class
