Imports System
Imports System.Collections
Imports System.Collections.Specialized
Imports System.IO

Public Class PasswordFile
  Private mFilename As String
  Private mFound As Boolean
  Private mIsValid As Boolean
  Private mDefaultPasswords As StringDictionary
  Private mLoadedPasswords As StringDictionary

  Public Sub New(ByVal fname As String)
      mFilename = fname
      mFound = False
      mIsValid = False
      mDefaultPasswords = New StringDictionary
      mLoadedPasswords = New StringDictionary

      ' look for file & validate & load passwords
      If (File.Exists(mFilename)) Then
        mFound = True
        ReadPasswordFile()
      End If
   End Sub

  Public ReadOnly Property PasswordFileFound() As Boolean
      Get
        Return mFound
      End Get
  End Property

  Public ReadOnly Property PasswordFilename() As String
      Get
        Return mFilename
      End Get
  End Property

  Public ReadOnly Property PasswordFileValid() As Boolean
      Get
        Return mIsValid
      End Get
  End Property

  Public Sub SetDefaultPassword(ByVal level As AccessLevel, ByVal pass As String)
    mDefaultPasswords.Add(level.ToString(), pass)
  End Sub

  Public Function GetPasswordForAccessLevel(ByVal level As AccessLevel) As String
      If (PasswordFileFound AndAlso PasswordFileValid) Then
        Return mLoadedPasswords(level.ToString())
      End If

      Return mDefaultPasswords(level.ToString())
  End Function

  Public Sub SetPasswordForAccessLevel(ByVal level As AccessLevel, ByVal pass As String)
    mLoadedPasswords(level.ToString()) = pass
  End Sub

  Private Sub ReadPasswordFile()
    mIsValid = False
    mLoadedPasswords.Clear()

    Dim filePasswords As StringDictionary = New StringDictionary

    ' read mFilename and fill mLoadedPasswords
    Dim fileLines As ArrayList = New ArrayList
    Dim line As String
    Try
      Dim sr As StreamReader = New StreamReader(mFilename)
      Try
        Do
          line = sr.ReadLine()
          If (Not line Is Nothing) Then
            fileLines.Add(line)
          End If
        Loop While Not line Is Nothing
      Finally
        sr.Close()
      End Try

    Catch
      Return
    End Try

    ' first line is "Version x"
    If (fileLines.Count < 1) Then
      Return
    End If

    line = CType(fileLines(0), String)
    If (Not line.StartsWith("Version ")) Then
      Return
    End If
    line = line.Substring(8)

    Dim ver As Integer = -1
    Try
      ver = [Integer].Parse(line)
    Catch
      Return
    End Try

    ' only version 1 supported at this time
    If (Not ver = 1) Then
      Return
    End If

    ' next lines are password lines
    Dim i As Integer
    For i = 1 To fileLines.Count - 1
      ' line to bytes
      Dim bytes() As Byte = Nothing
      If (Not ExtractBytesFromString(CType(fileLines(i), String), bytes)) Then
        Return
      End If

      ' do xor
      DoXOrDecode(bytes)

      ' decode accesslevel & password
      Dim level As AccessLevel
      Dim pass As String = Nothing
      If (Not Decode(bytes, level, pass)) Then
        Return
      End If

      ' put in table
      filePasswords.Add(level.ToString(), pass)
    Next i

    mIsValid = True
    mLoadedPasswords = filePasswords
  End Sub

  Private Sub AddString(ByVal bytes() As Byte, ByRef i As Integer, ByVal s As String)
    Dim c As Char
    For Each c In s
      Dim val As Integer = AscW(c)

      Dim high As Byte = CType((val >> 8), Byte)
      Dim low As Byte = CType((val And 255), Byte)
      bytes(i) = low
      i = i + 1
      bytes(i) = high
      i = i + 1
    Next c

    bytes(i) = 0
    i = i + 1
    bytes(i) = 0
    i = i + 1
  End Sub

  Private Function RemoveString(ByVal bytes As Byte(), ByRef i As Integer, ByRef s As String) As Boolean
    s = ""
    While i < bytes.Length
      Dim low As Byte = bytes(i)
      i = i + 1
      Dim high As Byte = bytes(i)
      i = i + 1

      Dim val As Integer = ((high << 8) + low)
      If (val = 0) Then
        Return True
      End If

      s += ChrW(val)
    End While

    Return False
  End Function

  Private Sub DoXOrEncode(ByVal bytes As Byte())
    Dim xorVal As Byte = 60
    Dim i As Integer
    For i = 0 To bytes.Length - 1
      bytes(i) = CType((bytes(i) Xor xorVal), Byte)
      Dim newxorval As Integer = xorVal
      newxorval = newxorval + bytes(i)
      xorVal = CType(newxorval Mod (Byte.MaxValue + 1), Byte)
    Next i
  End Sub

  Private Sub DoXOrDecode(ByVal bytes As Byte())
    Dim xorVal As Byte = 60
    Dim i As Integer
    For i = 0 To bytes.Length - 1
      Dim encodedval As Byte = bytes(i)
      bytes(i) = CType((bytes(i) Xor xorVal), Byte)
      Dim newxorval As Integer = xorVal
      newxorval = newxorval + encodedval
      xorVal = CType(newxorval Mod (Byte.MaxValue + 1), Byte)
    Next i
  End Sub

  Private Shared seed As Integer = CType(DateTime.Now.Ticks Mod Integer.MaxValue, Integer)

  Private Function Encode(ByVal level As String, ByVal pass As String) As Byte()
      Dim len As Integer = level.Length + 1 + pass.ToString().Length + 1
      len = len * 2
      If (len < 64) Then
        len = 64
      End If

      ' create & fill with random - careful to use a seed that changes
      Dim bytes As Byte() = New Byte(len - 1) {}
      Dim rand As Random = New Random(seed)
      seed = seed + 1
      rand.NextBytes(bytes)

      ' access level, zero, password, zero
      Dim i As Integer = 0
      AddString(bytes, i, level)
      AddString(bytes, i, pass)

      ' simple xor mod
      DoXOrEncode(bytes)

      Return bytes
  End Function

  Private Function Decode(ByVal bytes As Byte(), ByRef level As AccessLevel, ByRef pass As String) As Boolean
      Dim accessLevelString As String = Nothing
      pass = ""
      level = AccessLevel.[Operator]

      Dim i As Integer = 0
      If (Not RemoveString(bytes, i, accessLevelString)) Then
        Return False
      End If
      If (Not RemoveString(bytes, i, pass)) Then
        Return False
      End If

      Try
        Dim obj As Object = [Enum].Parse(GetType(AccessLevel), accessLevelString, True)
        level = CType(obj, AccessLevel)
      Catch
        Return False
      End Try

      Return True
  End Function

  Private Sub AddBytesToString(ByVal bytes As Byte(), ByRef str As String)
      Dim b As Byte
      For Each b In bytes
        str += b.ToString("X2")
      Next b
  End Sub

  Private Function ExtractBytesFromString(ByVal str As String, ByRef bytes As Byte()) As Boolean
      Try
        bytes = New Byte(str.Length / 2 - 1) {}

        Dim i As Integer
        For i = 0 To str.Length - 1 Step 2
          Dim bstr As String = str.Substring(i, 2)
          bytes(i / 2) = Byte.Parse(bstr, System.Globalization.NumberStyles.HexNumber)
        Next i
      Catch
        bytes = Nothing
        Return False
      End Try

      Return True
  End Function

  Public Sub WritePasswordFile()
    ' if we have a file open, write to that one - otherwise always
    ' write password file into current executable directory
    Dim fname As String = Utility.GetThisExecutableDirectory() + "passwords.txt"
    If (mFound) Then
      fname = mFilename
    End If

    ' check if passwords are same as default - if same as default and we
    ' don't have a file open, then don't write a file
    If (Not mFound AndAlso LoadedPasswordsSameAsDefault()) Then
        Return
    End If

    Dim fileContents As String = ""
    fileContents += "Version 1" + System.Environment.NewLine

    Dim de As System.Collections.DictionaryEntry
    For Each de In mLoadedPasswords
        Dim bytes As Byte() = Encode(de.Key.ToString(), de.Value.ToString())
        AddBytesToString(bytes, fileContents)
        fileContents += System.Environment.NewLine
    Next de

    Dim sw As StreamWriter = New StreamWriter(fname)
    Try
      sw.Write(fileContents)
    Finally
      sw.Close()
    End Try

    ' tbd - or read password file in again
    mFound = True
    mFilename = fname
    mIsValid = True
  End Sub

  Private Function LoadedPasswordsSameAsDefault() As Boolean
    If (Not mLoadedPasswords.Count = mDefaultPasswords.Count) Then
        Return False
    End If

    Dim de As System.Collections.DictionaryEntry
    For Each de In mLoadedPasswords
      If (Not de.Value.ToString() = mDefaultPasswords(de.Key.ToString())) Then
          Return False
      End If
    Next de
    Return True
  End Function

End Class
