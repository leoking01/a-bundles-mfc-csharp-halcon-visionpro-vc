Public Class FormSetPasswords
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New(ByVal pv As PasswordFile)
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        mPasswordFile = pv

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
Friend WithEvents groupBox_Supervisor As System.Windows.Forms.GroupBox
Friend WithEvents textBox_SupervisorConfirm As System.Windows.Forms.TextBox
Friend WithEvents textBox_SupervisorPassword As System.Windows.Forms.TextBox
Friend WithEvents label_ConfirmPassword1 As System.Windows.Forms.Label
Friend WithEvents label_Password1 As System.Windows.Forms.Label
Friend WithEvents button_Cancel As System.Windows.Forms.Button
Friend WithEvents button_OK As System.Windows.Forms.Button
Friend WithEvents groupBox_Administrator As System.Windows.Forms.GroupBox
Friend WithEvents textBox_AdministratorConfirm As System.Windows.Forms.TextBox
Friend WithEvents textBox_AdministratorPassword As System.Windows.Forms.TextBox
Friend WithEvents label_ConfirmPassword2 As System.Windows.Forms.Label
Friend WithEvents label_Password2 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
Me.groupBox_Supervisor = New System.Windows.Forms.GroupBox
Me.textBox_SupervisorConfirm = New System.Windows.Forms.TextBox
Me.textBox_SupervisorPassword = New System.Windows.Forms.TextBox
Me.label_ConfirmPassword1 = New System.Windows.Forms.Label
Me.label_Password1 = New System.Windows.Forms.Label
Me.button_Cancel = New System.Windows.Forms.Button
Me.button_OK = New System.Windows.Forms.Button
Me.groupBox_Administrator = New System.Windows.Forms.GroupBox
Me.textBox_AdministratorConfirm = New System.Windows.Forms.TextBox
Me.textBox_AdministratorPassword = New System.Windows.Forms.TextBox
Me.label_ConfirmPassword2 = New System.Windows.Forms.Label
Me.label_Password2 = New System.Windows.Forms.Label
Me.groupBox_Supervisor.SuspendLayout()
Me.groupBox_Administrator.SuspendLayout()
Me.SuspendLayout()
'
'groupBox_Supervisor
'
Me.groupBox_Supervisor.Controls.Add(Me.textBox_SupervisorConfirm)
Me.groupBox_Supervisor.Controls.Add(Me.textBox_SupervisorPassword)
Me.groupBox_Supervisor.Controls.Add(Me.label_ConfirmPassword1)
Me.groupBox_Supervisor.Controls.Add(Me.label_Password1)
Me.groupBox_Supervisor.Location = New System.Drawing.Point(15, 16)
Me.groupBox_Supervisor.Name = "groupBox_Supervisor"
Me.groupBox_Supervisor.Size = New System.Drawing.Size(400, 104)
Me.groupBox_Supervisor.TabIndex = 4
Me.groupBox_Supervisor.TabStop = False
Me.groupBox_Supervisor.Text = "Supervisor"
'
'textBox_SupervisorConfirm
'
Me.textBox_SupervisorConfirm.Location = New System.Drawing.Point(152, 64)
Me.textBox_SupervisorConfirm.Name = "textBox_SupervisorConfirm"
Me.textBox_SupervisorConfirm.PasswordChar = Microsoft.VisualBasic.ChrW(42)
Me.textBox_SupervisorConfirm.Size = New System.Drawing.Size(224, 20)
Me.textBox_SupervisorConfirm.TabIndex = 1
Me.textBox_SupervisorConfirm.Text = "textBox2"
'
'textBox_SupervisorPassword
'
Me.textBox_SupervisorPassword.Location = New System.Drawing.Point(152, 32)
Me.textBox_SupervisorPassword.Name = "textBox_SupervisorPassword"
Me.textBox_SupervisorPassword.PasswordChar = Microsoft.VisualBasic.ChrW(42)
Me.textBox_SupervisorPassword.Size = New System.Drawing.Size(224, 20)
Me.textBox_SupervisorPassword.TabIndex = 0
Me.textBox_SupervisorPassword.Text = "textBox1"
'
'label_ConfirmPassword1
'
Me.label_ConfirmPassword1.Location = New System.Drawing.Point(24, 64)
Me.label_ConfirmPassword1.Name = "label_ConfirmPassword1"
Me.label_ConfirmPassword1.Size = New System.Drawing.Size(128, 16)
Me.label_ConfirmPassword1.TabIndex = 1
Me.label_ConfirmPassword1.Text = "Confirm password:"
'
'label_Password1
'
Me.label_Password1.Location = New System.Drawing.Point(24, 32)
Me.label_Password1.Name = "label_Password1"
Me.label_Password1.Size = New System.Drawing.Size(128, 16)
Me.label_Password1.TabIndex = 0
Me.label_Password1.Text = "Password:"
'
'button_Cancel
'
Me.button_Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
Me.button_Cancel.Location = New System.Drawing.Point(239, 256)
Me.button_Cancel.Name = "button_Cancel"
Me.button_Cancel.Size = New System.Drawing.Size(88, 23)
Me.button_Cancel.TabIndex = 7
Me.button_Cancel.Text = "Cancel"
'
'button_OK
'
Me.button_OK.DialogResult = System.Windows.Forms.DialogResult.OK
Me.button_OK.Location = New System.Drawing.Point(95, 256)
Me.button_OK.Name = "button_OK"
Me.button_OK.Size = New System.Drawing.Size(88, 23)
Me.button_OK.TabIndex = 6
Me.button_OK.Text = "Ok"
'
'groupBox_Administrator
'
Me.groupBox_Administrator.Controls.Add(Me.textBox_AdministratorConfirm)
Me.groupBox_Administrator.Controls.Add(Me.textBox_AdministratorPassword)
Me.groupBox_Administrator.Controls.Add(Me.label_ConfirmPassword2)
Me.groupBox_Administrator.Controls.Add(Me.label_Password2)
Me.groupBox_Administrator.Location = New System.Drawing.Point(15, 136)
Me.groupBox_Administrator.Name = "groupBox_Administrator"
Me.groupBox_Administrator.Size = New System.Drawing.Size(400, 104)
Me.groupBox_Administrator.TabIndex = 5
Me.groupBox_Administrator.TabStop = False
Me.groupBox_Administrator.Text = "Administrator"
'
'textBox_AdministratorConfirm
'
Me.textBox_AdministratorConfirm.Location = New System.Drawing.Point(152, 64)
Me.textBox_AdministratorConfirm.Name = "textBox_AdministratorConfirm"
Me.textBox_AdministratorConfirm.PasswordChar = Microsoft.VisualBasic.ChrW(42)
Me.textBox_AdministratorConfirm.Size = New System.Drawing.Size(224, 20)
Me.textBox_AdministratorConfirm.TabIndex = 1
Me.textBox_AdministratorConfirm.Text = "textbox2"
'
'textBox_AdministratorPassword
'
Me.textBox_AdministratorPassword.Location = New System.Drawing.Point(152, 32)
Me.textBox_AdministratorPassword.Name = "textBox_AdministratorPassword"
Me.textBox_AdministratorPassword.PasswordChar = Microsoft.VisualBasic.ChrW(42)
Me.textBox_AdministratorPassword.Size = New System.Drawing.Size(224, 20)
Me.textBox_AdministratorPassword.TabIndex = 0
Me.textBox_AdministratorPassword.Text = "textBox1"
'
'label_ConfirmPassword2
'
Me.label_ConfirmPassword2.Location = New System.Drawing.Point(24, 64)
Me.label_ConfirmPassword2.Name = "label_ConfirmPassword2"
Me.label_ConfirmPassword2.Size = New System.Drawing.Size(128, 16)
Me.label_ConfirmPassword2.TabIndex = 1
Me.label_ConfirmPassword2.Text = "Confirm password:"
'
'label_Password2
'
Me.label_Password2.Location = New System.Drawing.Point(24, 32)
Me.label_Password2.Name = "label_Password2"
Me.label_Password2.Size = New System.Drawing.Size(128, 16)
Me.label_Password2.TabIndex = 0
Me.label_Password2.Text = "Password:"
'
'FormSetPasswords
'
Me.AcceptButton = Me.button_OK
Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
Me.CancelButton = Me.button_Cancel
Me.ClientSize = New System.Drawing.Size(430, 302)
Me.Controls.Add(Me.groupBox_Supervisor)
Me.Controls.Add(Me.button_Cancel)
Me.Controls.Add(Me.button_OK)
Me.Controls.Add(Me.groupBox_Administrator)
Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
Me.MaximizeBox = False
Me.MinimizeBox = False
Me.Name = "FormSetPasswords"
Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
Me.Text = "FormSetPasswords"
Me.groupBox_Supervisor.ResumeLayout(False)
Me.groupBox_Administrator.ResumeLayout(False)
Me.ResumeLayout(False)

    End Sub

#End Region

  Private mPasswordFile As PasswordFile

Private Sub FormSetPasswords_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
  Me.Text = ResourceUtility.GetString("RtSetPasswordsTitle")
  groupBox_Administrator.Text = ResourceUtility.GetString("RtAdministrator")
  groupBox_Supervisor.Text = ResourceUtility.GetString("RtSupervisor")
  label_ConfirmPassword1.Text = ResourceUtility.GetString("RtConfirmPassword")
  label_ConfirmPassword2.Text = label_ConfirmPassword1.Text
  label_Password1.Text = ResourceUtility.GetString("RtPassword")
  label_Password2.Text = label_Password1.Text
  button_Cancel.Text = ResourceUtility.GetString("RtCancel")
  button_OK.Text = ResourceUtility.GetString("RtOK")

  textBox_SupervisorPassword.Text = mPasswordFile.GetPasswordForAccessLevel(AccessLevel.Supervisor)
  textBox_SupervisorConfirm.Text = textBox_SupervisorPassword.Text

  textBox_AdministratorPassword.Text = mPasswordFile.GetPasswordForAccessLevel(AccessLevel.Administrator)
  textBox_AdministratorConfirm.Text = textBox_AdministratorPassword.Text

  EnableOk()

End Sub

Private Sub EnableOk()
  ' enable ok button based on dialog contents
  Dim en As Boolean = False

  ' confirms must match and passwords must not be empty
  If (textBox_AdministratorConfirm.Text = textBox_AdministratorPassword.Text AndAlso _
      textBox_SupervisorConfirm.Text = textBox_SupervisorPassword.Text AndAlso _
      Not textBox_AdministratorPassword.Text = "" AndAlso _
      Not textBox_SupervisorPassword.Text = "") Then

    ' password must have changed
    If (Not textBox_AdministratorPassword.Text = mPasswordFile.GetPasswordForAccessLevel(AccessLevel.Administrator) Or _
          Not textBox_SupervisorPassword.Text = mPasswordFile.GetPasswordForAccessLevel(AccessLevel.Supervisor)) Then
      en = True
    End If
  End If

  button_OK.Enabled = en
End Sub

Private Sub textBox_Password_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles textBox_AdministratorConfirm.TextChanged, _
                                                                                                      textBox_AdministratorPassword.TextChanged, _
                                                                                                      textBox_SupervisorConfirm.TextChanged, _
                                                                                                      textBox_SupervisorPassword.TextChanged
  EnableOk()
End Sub

Private Sub button_OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button_OK.Click
  mPasswordFile.SetPasswordForAccessLevel(AccessLevel.Supervisor, textBox_SupervisorPassword.Text)
  mPasswordFile.SetPasswordForAccessLevel(AccessLevel.Administrator, textBox_AdministratorPassword.Text)

  ' writes a password file only if needed
  mPasswordFile.WritePasswordFile()

End Sub

End Class
