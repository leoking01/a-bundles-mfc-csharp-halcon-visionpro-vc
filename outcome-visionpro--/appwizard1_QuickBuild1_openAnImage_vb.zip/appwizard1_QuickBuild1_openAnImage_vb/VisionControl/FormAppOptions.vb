Public Class FormAppOptions
    Inherits System.Windows.Forms.Form

    Public EnableDisplay As Boolean
    Public EnableIOAtStartup As Boolean
    Public EnableIO As Boolean
    Private WithEvents groupBox_IOOptions As System.Windows.Forms.GroupBox
    Private WithEvents checkBox_EnableIOAtStartup As System.Windows.Forms.CheckBox
    Private WithEvents radioButton_Offline As System.Windows.Forms.RadioButton
    Private WithEvents radioButton_Online As System.Windows.Forms.RadioButton
    Private WithEvents label_CurrentIOState As System.Windows.Forms.Label
    Private mApplicationForm As VisionControl

#Region " Windows Form Designer generated code "

    Public Sub New(ByVal app As VisionControl)
        MyBase.New()

        mApplicationForm = app

        'This call is required by the Windows Form Designer.
        InitializeComponent()
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
Friend WithEvents button_Cancel As System.Windows.Forms.Button
Friend WithEvents button_OK As System.Windows.Forms.Button
Friend WithEvents CheckBox_EnableDisplay As System.Windows.Forms.CheckBox
Friend WithEvents groupBox_DisplayOptions As System.Windows.Forms.GroupBox
Friend WithEvents groupBox_QueueOptions As System.Windows.Forms.GroupBox
Friend WithEvents button_ClearQueues As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.button_Cancel = New System.Windows.Forms.Button
        Me.button_OK = New System.Windows.Forms.Button
        Me.groupBox_DisplayOptions = New System.Windows.Forms.GroupBox
        Me.CheckBox_EnableDisplay = New System.Windows.Forms.CheckBox
        Me.groupBox_QueueOptions = New System.Windows.Forms.GroupBox
        Me.button_ClearQueues = New System.Windows.Forms.Button
        Me.groupBox_IOOptions = New System.Windows.Forms.GroupBox
        Me.checkBox_EnableIOAtStartup = New System.Windows.Forms.CheckBox
        Me.radioButton_Offline = New System.Windows.Forms.RadioButton
        Me.radioButton_Online = New System.Windows.Forms.RadioButton
        Me.label_CurrentIOState = New System.Windows.Forms.Label
        Me.groupBox_DisplayOptions.SuspendLayout()
        Me.groupBox_QueueOptions.SuspendLayout()
        Me.groupBox_IOOptions.SuspendLayout()
        Me.SuspendLayout()
        '
        'button_Cancel
        '
        Me.button_Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.button_Cancel.Location = New System.Drawing.Point(215, 365)
        Me.button_Cancel.Name = "button_Cancel"
        Me.button_Cancel.Size = New System.Drawing.Size(75, 23)
        Me.button_Cancel.TabIndex = 5
        Me.button_Cancel.Text = "Cancel"
        '
        'button_OK
        '
        Me.button_OK.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.button_OK.Location = New System.Drawing.Point(86, 365)
        Me.button_OK.Name = "button_OK"
        Me.button_OK.Size = New System.Drawing.Size(75, 23)
        Me.button_OK.TabIndex = 4
        Me.button_OK.Text = "Ok"
        '
        'groupBox_DisplayOptions
        '
        Me.groupBox_DisplayOptions.Controls.Add(Me.CheckBox_EnableDisplay)
        Me.groupBox_DisplayOptions.Location = New System.Drawing.Point(24, 16)
        Me.groupBox_DisplayOptions.Name = "groupBox_DisplayOptions"
        Me.groupBox_DisplayOptions.Size = New System.Drawing.Size(328, 80)
        Me.groupBox_DisplayOptions.TabIndex = 3
        Me.groupBox_DisplayOptions.TabStop = False
        Me.groupBox_DisplayOptions.Text = "groupBox_DisplayOptions"
        '
        'CheckBox_EnableDisplay
        '
        Me.CheckBox_EnableDisplay.Location = New System.Drawing.Point(40, 32)
        Me.CheckBox_EnableDisplay.Name = "CheckBox_EnableDisplay"
        Me.CheckBox_EnableDisplay.Size = New System.Drawing.Size(272, 24)
        Me.CheckBox_EnableDisplay.TabIndex = 0
        Me.CheckBox_EnableDisplay.Text = "CheckBox_EnableDisplay"
        '
        'groupBox_QueueOptions
        '
        Me.groupBox_QueueOptions.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.groupBox_QueueOptions.Controls.Add(Me.button_ClearQueues)
        Me.groupBox_QueueOptions.Location = New System.Drawing.Point(25, 112)
        Me.groupBox_QueueOptions.Name = "groupBox_QueueOptions"
        Me.groupBox_QueueOptions.Size = New System.Drawing.Size(328, 80)
        Me.groupBox_QueueOptions.TabIndex = 6
        Me.groupBox_QueueOptions.TabStop = False
        Me.groupBox_QueueOptions.Text = "groupBox_QueueOptions"
        '
        'button_ClearQueues
        '
        Me.button_ClearQueues.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.button_ClearQueues.Location = New System.Drawing.Point(88, 32)
        Me.button_ClearQueues.Name = "button_ClearQueues"
        Me.button_ClearQueues.Size = New System.Drawing.Size(144, 23)
        Me.button_ClearQueues.TabIndex = 0
        Me.button_ClearQueues.Text = "Clear History Queues"
        '
        'groupBox_IOOptions
        '
        Me.groupBox_IOOptions.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.groupBox_IOOptions.Controls.Add(Me.checkBox_EnableIOAtStartup)
        Me.groupBox_IOOptions.Controls.Add(Me.radioButton_Offline)
        Me.groupBox_IOOptions.Controls.Add(Me.radioButton_Online)
        Me.groupBox_IOOptions.Controls.Add(Me.label_CurrentIOState)
        Me.groupBox_IOOptions.Location = New System.Drawing.Point(25, 205)
        Me.groupBox_IOOptions.Name = "groupBox_IOOptions"
        Me.groupBox_IOOptions.Size = New System.Drawing.Size(328, 140)
        Me.groupBox_IOOptions.TabIndex = 7
        Me.groupBox_IOOptions.TabStop = False
        Me.groupBox_IOOptions.Text = "groupBox_IOOptions"
        '
        'checkBox_EnableIOAtStartup
        '
        Me.checkBox_EnableIOAtStartup.AutoSize = True
        Me.checkBox_EnableIOAtStartup.Location = New System.Drawing.Point(39, 110)
        Me.checkBox_EnableIOAtStartup.Name = "checkBox_EnableIOAtStartup"
        Me.checkBox_EnableIOAtStartup.Size = New System.Drawing.Size(168, 17)
        Me.checkBox_EnableIOAtStartup.TabIndex = 3
        Me.checkBox_EnableIOAtStartup.Text = "checkBox_EnableIOAtStartup"
        Me.checkBox_EnableIOAtStartup.UseVisualStyleBackColor = True
        '
        'radioButton_Offline
        '
        Me.radioButton_Offline.AutoSize = True
        Me.radioButton_Offline.Location = New System.Drawing.Point(54, 73)
        Me.radioButton_Offline.Name = "radioButton_Offline"
        Me.radioButton_Offline.Size = New System.Drawing.Size(115, 17)
        Me.radioButton_Offline.TabIndex = 2
        Me.radioButton_Offline.TabStop = True
        Me.radioButton_Offline.Text = "radioButton_Offline"
        Me.radioButton_Offline.UseVisualStyleBackColor = True
        '
        'radioButton_Online
        '
        Me.radioButton_Online.AutoSize = True
        Me.radioButton_Online.Location = New System.Drawing.Point(54, 50)
        Me.radioButton_Online.Name = "radioButton_Online"
        Me.radioButton_Online.Size = New System.Drawing.Size(115, 17)
        Me.radioButton_Online.TabIndex = 1
        Me.radioButton_Online.TabStop = True
        Me.radioButton_Online.Text = "radioButton_Online"
        Me.radioButton_Online.UseVisualStyleBackColor = True
        '
        'label_CurrentIOState
        '
        Me.label_CurrentIOState.AutoSize = True
        Me.label_CurrentIOState.Location = New System.Drawing.Point(36, 32)
        Me.label_CurrentIOState.Name = "label_CurrentIOState"
        Me.label_CurrentIOState.Size = New System.Drawing.Size(105, 13)
        Me.label_CurrentIOState.TabIndex = 0
        Me.label_CurrentIOState.Text = "label_CurrentIOState"
        '
        'FormAppOptions
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(378, 409)
        Me.Controls.Add(Me.groupBox_IOOptions)
        Me.Controls.Add(Me.groupBox_QueueOptions)
        Me.Controls.Add(Me.button_Cancel)
        Me.Controls.Add(Me.button_OK)
        Me.Controls.Add(Me.groupBox_DisplayOptions)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FormAppOptions"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "FormAppOptions"
        Me.groupBox_DisplayOptions.ResumeLayout(False)
        Me.groupBox_QueueOptions.ResumeLayout(False)
        Me.groupBox_IOOptions.ResumeLayout(False)
        Me.groupBox_IOOptions.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

#End Region

Private Sub FormAppOptions_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
  CheckBox_EnableDisplay.Checked = EnableDisplay
  checkBox_EnableIOAtStartup.Checked = EnableIOAtStartup
  radioButton_Online.Checked = EnableIO
  radioButton_Offline.Checked = Not EnableIO

  Me.Text = ResourceUtility.GetString("RtAppOptionsTitle")
  Me.groupBox_DisplayOptions.Text = ResourceUtility.GetString("RtGroupDisplayOptions")
  Me.groupBox_QueueOptions.Text = ResourceUtility.GetString("RtGroupQueueOptions")
  Me.groupBox_IOOptions.Text = ResourceUtility.GetString("RtGroupIOOptions")
  Me.CheckBox_EnableDisplay.Text = ResourceUtility.GetString("RtEnableDisplay")
  Me.button_ClearQueues.Text = ResourceUtility.GetString("RtClearQueues")
  Me.label_CurrentIOState.Text = ResourceUtility.GetString("RtCurrentIOState")
  Me.radioButton_Online.Text = ResourceUtility.GetString("RtOnline")
  Me.radioButton_Offline.Text = ResourceUtility.GetString("RtOffline")
  Me.checkBox_EnableIOAtStartup.Text = ResourceUtility.GetString("RtEnableIOAtStartup")
  Me.button_Cancel.Text = ResourceUtility.GetString("RtCancel")
  Me.button_OK.Text = ResourceUtility.GetString("RtOK")
End Sub

Private Sub FormAppOptions_Closing(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
  EnableDisplay = CheckBox_EnableDisplay.Checked
  EnableIOAtStartup = checkBox_EnableIOAtStartup.Checked
  EnableIO = radioButton_Online.Checked
End Sub

Private Sub button_ClearQueues_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button_ClearQueues.Click
  mApplicationForm.ClearHistoryQueues(sender, e)
End Sub

End Class
