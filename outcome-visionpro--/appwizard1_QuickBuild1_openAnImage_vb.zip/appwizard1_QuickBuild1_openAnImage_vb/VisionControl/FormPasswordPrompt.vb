Public Class FormPasswordPrompt
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        mPassword = ""

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
Friend WithEvents button_Cancel As System.Windows.Forms.Button
Friend WithEvents button_OK As System.Windows.Forms.Button
Friend WithEvents textBox_Password As System.Windows.Forms.TextBox
Friend WithEvents label_Password As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
Me.button_Cancel = New System.Windows.Forms.Button
Me.button_OK = New System.Windows.Forms.Button
Me.textBox_Password = New System.Windows.Forms.TextBox
Me.label_Password = New System.Windows.Forms.Label
Me.SuspendLayout()
'
'button_Cancel
'
Me.button_Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
Me.button_Cancel.Location = New System.Drawing.Point(200, 64)
Me.button_Cancel.Name = "button_Cancel"
Me.button_Cancel.Size = New System.Drawing.Size(84, 23)
Me.button_Cancel.TabIndex = 6
Me.button_Cancel.Text = "Cancel"
'
'button_OK
'
Me.button_OK.DialogResult = System.Windows.Forms.DialogResult.OK
Me.button_OK.Location = New System.Drawing.Point(64, 64)
Me.button_OK.Name = "button_OK"
Me.button_OK.Size = New System.Drawing.Size(84, 23)
Me.button_OK.TabIndex = 5
Me.button_OK.Text = "Ok"
'
'textBox_Password
'
Me.textBox_Password.Location = New System.Drawing.Point(136, 22)
Me.textBox_Password.Name = "textBox_Password"
Me.textBox_Password.PasswordChar = Microsoft.VisualBasic.ChrW(42)
Me.textBox_Password.Size = New System.Drawing.Size(168, 20)
Me.textBox_Password.TabIndex = 3
Me.textBox_Password.Text = ""
'
'label_Password
'
Me.label_Password.Location = New System.Drawing.Point(32, 24)
Me.label_Password.Name = "label_Password"
Me.label_Password.Size = New System.Drawing.Size(96, 16)
Me.label_Password.TabIndex = 4
Me.label_Password.Text = "Password:"
'
'FormPasswordPrompt
'
Me.AcceptButton = Me.button_OK
Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
Me.CancelButton = Me.button_Cancel
Me.ClientSize = New System.Drawing.Size(350, 108)
Me.Controls.Add(Me.button_Cancel)
Me.Controls.Add(Me.button_OK)
Me.Controls.Add(Me.textBox_Password)
Me.Controls.Add(Me.label_Password)
Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
Me.MaximizeBox = False
Me.MinimizeBox = False
Me.Name = "FormPasswordPrompt"
Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
Me.Text = "FormPasswordPrompt"
Me.ResumeLayout(False)

    End Sub

#End Region

  Private mPassword As String

  Public ReadOnly Property Password() As String
    Get
      Return mPassword
    End Get
  End Property

Private Sub button_OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button_OK.Click
  mPassword = textBox_Password.Text
End Sub

Private Sub FormPasswordPrompt_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
  label_Password.Text = ResourceUtility.GetString("RtPassword")
  button_OK.Text = ResourceUtility.GetString("RtOK")
  button_Cancel.Text = ResourceUtility.GetString("RtCancel")
End Sub

End Class
