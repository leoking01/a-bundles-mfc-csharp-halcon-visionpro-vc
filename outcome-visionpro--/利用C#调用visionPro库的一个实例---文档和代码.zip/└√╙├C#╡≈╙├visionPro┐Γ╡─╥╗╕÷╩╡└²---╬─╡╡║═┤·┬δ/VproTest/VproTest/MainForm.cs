﻿using System;
//using System.String;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Cognex.VisionPro.ImageFile;
using Cognex.VisionPro.ToolBlock;
using Cognex.VisionPro;

namespace VproTest001
{
    public partial class MainForm : Form
    {
        CogToolBlock m_tb;
        CogImageFile imagefile;

        TooblockForm dlg;
        int count;
        int count_local  ;


        public MainForm()
        {
            InitializeComponent();
            count_local = 0;
            count = 0;
        }


        //打开图像 
        private void btn_openimage_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog dlg = new OpenFileDialog();
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    //读取图像
                    CogImageFile imagefile_0 = new CogImageFile();
                    imagefile_0.Open(dlg.FileName, CogImageFileModeConstants.Read);

                    count = imagefile_0.Count;  
                    imagefile = imagefile_0;

                    // 显示图像，这里显示第一张图像先
                    //m_Image8Gray = (CogImage8Grey)imagefile[0];
                    //CogImage24PlanarColor  m_Image8Gray = (CogImage24PlanarColor)imagefile[0];

                    //cogRecordDisplay1.Image = imagefile[0];
                    cogRecordDisplay1.Image = (CogImage8Grey)imagefile[0];
                    cogRecordDisplay1.Fit();

                    m_tb.Inputs["OutputImage"].Value = (CogImage8Grey)imagefile[0];
                }
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Exception:类型不对，只接受8位灰度图像。");
            }
            finally
            {
            }
        }


        //winform默认加载
        private void MainForm_Load(object sender, EventArgs e)
        {
            m_tb = new CogToolBlock();
            m_tb = (CogToolBlock)CogSerializer.LoadObjectFromFile(Application.StartupPath + "/../../../../TestMY.vpp");

            dlg = new TooblockForm();
            dlg.tb = m_tb;
        }


        //编辑block 
        private void btn_edittoolblock_Click(object sender, EventArgs e)
        {
            //dlg.tb.Inputs["OutputImage"].Value = m_Image8Gray;
            dlg.ShowDialog();
        }


        //运行 
        private void btn_Run_Click(object sender, EventArgs e)
        {
            //CogImage8Grey m_Image8Gray = new CogImage8Grey();
            if (count <= 0)
            {
                MessageBox.Show("没有图像被读取。");
                return;
            }
              
            int id = count_local % count;
            count_local ++ ;
            CogImage8Grey m_Image8Gray = (CogImage8Grey)imagefile[id];
            m_tb.Inputs["OutputImage"].Value = m_Image8Gray;
            if (true)
            {
                //m_tb.Inputs["OutputImage"].Value = m_Image8Gray;
                m_tb.Run();

                cogRecordDisplay1.Image = m_Image8Gray;
                cogRecordDisplay1.Record = m_tb.CreateLastRunRecord().SubRecords[0];
                cogRecordDisplay1.Fit();

                textBox1.Text = m_tb.Outputs["Results_Item_0_Score"].Value.ToString();
                double angle = (double)m_tb.Outputs["Results_Item_0_GetPose_Rotation"].Value;
                textBox2.Text = angle.ToString();
                textBox3.Text = m_tb.Outputs["Results_Item_0_GetPose_TranslationY"].Value.ToString();
            }
        }


        //输入图像：bmp灰度图像仅限,只能转换8位的bmp图像，好坑
        //输出图像：灰度康耐视图像  
        public void trans_bmp_2_cogGray(System.Drawing.Bitmap bp, Cognex.VisionPro.CogImage8Grey cogImage8Grey)
        {
            // 读取BitMap图像
            //System.Drawing.Bitmap curBitmap = new Bitmap("C:\\imagesA/star.bmp");
            System.Drawing.Bitmap curBitmap = bp;
            // 定义处理区域
            Rectangle rect = new Rectangle(0, 0, curBitmap.Width, curBitmap.Height);
            // 获取像素数据
            System.Drawing.Imaging.BitmapData bmpData = curBitmap.LockBits(rect, System.Drawing.Imaging.ImageLockMode.ReadOnly, curBitmap.PixelFormat);
            // 获取像素数据指针
            IntPtr IntPtrPixelData = bmpData.Scan0;
            // 定义Buffer
            byte[] PixelDataBuffer = new byte[curBitmap.Width * curBitmap.Height];
            // 拷贝Bitmap的像素数据的到Buffer
            System.Runtime.InteropServices.Marshal.Copy(IntPtrPixelData, PixelDataBuffer, 0, PixelDataBuffer.Length);
            // 创建CogImage8Grey
            //Cognex.VisionPro.CogImage8Grey cogImage8Grey = new Cognex.VisionPro.CogImage8Grey(curBitmap.Width, curBitmap.Height);
            // 获取CogImage8Grey的像素数据指针
            IntPtr Image8GreyIntPtr = cogImage8Grey.Get8GreyPixelMemory(Cognex.VisionPro.CogImageDataModeConstants.Read, 0, 0, cogImage8Grey.Width, cogImage8Grey.Height).Scan0;
            // 拷贝Buffer数据到CogImage8Grey的像素数据区
            System.Runtime.InteropServices.Marshal.Copy(PixelDataBuffer, 0, Image8GreyIntPtr, PixelDataBuffer.Length);
            // 显示图像
            //cogRecordDisplay1.Image = cogImage8Grey;
            //cogRecordDisplay1.Fit();
            //cogGray = cogImage8Grey;
        }


        private void transBmp2CogGray_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            string nameOfFile = "";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                //读取图像
                //CogImageFile imagefile_0 = new CogImageFile();
                //imagefile_0.Open(dlg.FileName, CogImageFileModeConstants.Read);
                //int ct = imagefile_0.Count;
                //获取文件名称 
                nameOfFile = dlg.FileName;
            }

            try
            {
                //System.Drawing.Bitmap curBitmap = new Bitmap("C:\\imagesA/star.bmp");
                //System.Drawing.Bitmap curBitmap = new Bitmap("C:\\Images/2DSym-144x144.bmp");
                //System.Drawing.Bitmap curBitmap = new Bitmap("C:\\Images/bracket_mask.bmp");
                System.Drawing.Bitmap curBitmap = new Bitmap(nameOfFile);
                Cognex.VisionPro.CogImage8Grey cogGray = new Cognex.VisionPro.CogImage8Grey(curBitmap.Width, curBitmap.Height);
                trans_bmp_2_cogGray(curBitmap, cogGray);  //输入图像：bmp灰度图像仅限,只能转换8位的bmp图像，好坑
                cogRecordDisplay1.Image = cogGray;
                cogRecordDisplay1.Fit();
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Exception:类型不对，只接受8位灰度图像bmp格式。");
            }
            finally
            {
            }
        }
    }
}


