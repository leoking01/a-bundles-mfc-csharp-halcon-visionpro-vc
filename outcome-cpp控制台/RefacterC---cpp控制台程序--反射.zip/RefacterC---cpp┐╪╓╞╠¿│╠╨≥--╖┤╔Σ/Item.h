#pragma once
#include "Object.h"

//����Item�Ļ���
class Item : public Object
{
public:
	Item();
	virtual ~Item();

	virtual void Print() = 0;

};

