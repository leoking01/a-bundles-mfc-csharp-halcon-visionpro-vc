#include "stdafx.h"
#include "Object.h"


Object::Object()
{
}

Object::~Object()
{

}

