#pragma once

template<class T>
class Singleton
{
public:
#undef CPLUSPLUS_11__UU
#ifdef CPLUSPLUS_11__UU
	using   object_type T;
#else 
	typedef  T object_type  ;
#endif

	//typedef  T object_type  ;

	struct object_creator
	{
		object_creator() { Singleton<T>::instance(); }
	};

	static object_creator creator_object;
public:
	static object_type* instance()
	{
		static object_type _instance;
		return &_instance;
	}
};

template<typename T> typename Singleton<T>::object_creator Singleton<T>::creator_object;





