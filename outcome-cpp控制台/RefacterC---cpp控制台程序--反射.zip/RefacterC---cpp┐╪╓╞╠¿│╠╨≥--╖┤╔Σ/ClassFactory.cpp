#include "stdafx.h"
#include "ClassFactory.h"



ClassFactory::ClassFactory()
{
}


ClassFactory::~ClassFactory()
{
#undef CPLUSPLUS_11__UU
#ifdef CPLUSPLUS_11__UU
	for (auto it : objectItems)
	{
		if (it.second != nullptr)
		{
			delete it.second;
			it.second = nullptr;
		}
	}
#else
	for (map<string, ItemObjectClass *>::iterator it = objectItems.begin();
		it!= objectItems.end();it++
		)
	{
		if (it->second != nullptr)
		{
			delete it->second;
			it->second = nullptr;
		}
	}
#endif

	//for (map<string, ItemObjectClass *>::iterator it = objectItems.begin();
	//	it!= objectItems.end();it++
	//	)
	//{
	//	if (it->second != nullptr)
	//	{
	//		delete it->second;
	//		it->second = nullptr;
	//	}
	//}


	objectItems.clear();
}


//����void *�����˴�������
void * ClassFactory::CreateItem(string className)
{
	ItemObject constructor = nullptr;

	if (objectItems.find(className) != objectItems.end())
		constructor = objectItems.find(className)->second->itemObject;

	if (constructor == nullptr)
		return nullptr;

	// ���ú���ָ��ָ��ĺ��� ����REGISTER_CLASS�к�İ󶨺�����Ҳ��������new className����
	return (*constructor)();
}

//ItemObject�൱��һ���ص�����
void ClassFactory::RegisterItem(const string& className, ItemObject item)
{
	map<string, ItemObjectClass *>::iterator it = objectItems.find(className);
	if (it != objectItems.end())
		objectItems[className]->itemObject = item;
	else
		objectItems.insert(make_pair(className, new ItemObjectClass(item)));
}
