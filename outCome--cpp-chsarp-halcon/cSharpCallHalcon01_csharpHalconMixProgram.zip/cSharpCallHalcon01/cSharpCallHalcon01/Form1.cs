﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


using HalconDotNet;

namespace cSharpCallHalcon01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            HDevelopExport HD = new HDevelopExport();
            HD.RunHalcon( hWindowControl1.HalconWindow );
        }

    }



    public partial class HDevelopExport
    {
        public HTuple hv_ExpDefaultWinHandle;

        // Main procedure 
        private void imageReadAndShow()
        {
            // Local iconic variables 
            HObject ho_image;

            // Local control variables 
            HTuple hv_width = null, hv_height = null;
            // Initialize local and output iconic variables 
            HOperatorSet.GenEmptyObj(out ho_image);
            //dev_close_window(...);
            ho_image.Dispose();
            HOperatorSet.ReadImage(out ho_image, "../../images/star.jpeg");
            HOperatorSet.GetImageSize(ho_image, out hv_width, out hv_height);

            //dev_open_window(...);
            HOperatorSet.DispObj(ho_image, hv_ExpDefaultWinHandle);
            ho_image.Dispose();

        }

        //public void InitHalcon()
        //{
        //    // Default settings used in HDevelop 
        //    HOperatorSet.SetSystem("width", 512);
        //    HOperatorSet.SetSystem("height", 512);
        //}

        public void RunHalcon(HTuple Window)
        {
            hv_ExpDefaultWinHandle = Window;
            imageReadAndShow();
        }
    }





}
