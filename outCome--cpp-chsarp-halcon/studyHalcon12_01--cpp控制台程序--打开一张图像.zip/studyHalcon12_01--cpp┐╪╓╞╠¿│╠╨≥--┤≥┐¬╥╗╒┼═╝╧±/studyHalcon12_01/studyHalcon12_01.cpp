// studyHalcon12_01.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"

#include <iostream>
using  namespace  std;

#include "cpp/HalconCpp.h"
using  namespace  Halcon;

int _tmain(   int argc, _TCHAR* argv[]   )
{
	//
	cout<<"program start: "<< endl;


	// halcon image show  demo  
	string  nameImage_gray ;
	nameImage_gray = "D:\\images/star.jpeg" ;
	nameImage_gray = "D:\\images/2.jpg" ;
	nameImage_gray = "D:\\images/star01.bmp" ;
	HRegionArray Eyes;
	HByteImage  Mandrill(  nameImage_gray.c_str() );
	//Mandrill.
	HWindow w(0,0,Mandrill.Width()-1, Mandrill.Height()-1 );
	Mandrill.Display( w );
	w.Click();

	return 0;
}

