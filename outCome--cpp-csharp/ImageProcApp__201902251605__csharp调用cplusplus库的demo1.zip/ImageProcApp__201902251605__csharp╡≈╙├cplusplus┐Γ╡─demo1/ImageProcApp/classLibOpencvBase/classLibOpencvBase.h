// classLibOpencvBase.h

#pragma once



#if  (defined WIN32 || defined _WIN32 || defined WINCE  ) &&  defined MYDLL_EXPORTS 
#define  OPENCV_WARP_API_EXPORTS  _declspec(dllexport)
#else
#define  OPENCV_WARP_API_EXPORTS 
#endif 

namespace TestCppDll
{
 extern "C" __declspec(dllexport) int __stdcall add_lk( int a, int b   );
}

  OPENCV_WARP_API_EXPORTS  class  CNaiveCpp 
{
public: 
	CNaiveCpp()
	{
	}
	~CNaiveCpp()
	{
	}
public:
	int  denoise()
	{
		return 0;
	}

	int  getA()
	{
		return 10;
	}
};




using namespace System;

 namespace classLibOpencvBase {

public  ref    class  LkProccesion
	{
		// TODO: �ڴ˴����Ӵ���ķ�����
	public:
		  LkProccesion()
		{

		}
		  ~LkProccesion()
		{

		}
	public:
		  int  getB()
		  {
			  CNaiveCpp   ca;
			  return ca.getA();
		  }


	};
};


