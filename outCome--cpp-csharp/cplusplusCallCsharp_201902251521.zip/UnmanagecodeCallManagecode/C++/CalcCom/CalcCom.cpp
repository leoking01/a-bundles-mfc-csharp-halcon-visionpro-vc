// CalcCom.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"

#include "CalcCom.h"





BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}


BOOL Add (char* a,char* b,long* c)
{
	CoInitialize(NULL);
	CalcClass::ICalcPtr CalcPtr(__uuidof(Calc));//��ȡCalc��������GUID
	VARIANT_BOOL ret =	CalcPtr->Add(_bstr_t(a),_bstr_t(b),c);
	CalcPtr->Release();
	CoUninitialize();   
	if( ret == -1 )
		return 1;
	else
		return ret;
}



void Join (char* a,char* b,char* c){
	CoInitialize(NULL);
	CalcClass::ICalcPtr CalcPtr(__uuidof(Calc));//��ȡCalc��������GUID
	BSTR temp;
	CalcPtr->Join(_bstr_t(a),_bstr_t(b),&temp);
	strcpy(c , _com_util::ConvertBSTRToString(temp));
	CalcPtr->Release();
	CoUninitialize();   
}




