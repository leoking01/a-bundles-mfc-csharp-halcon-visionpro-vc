// CalcComDemoDlg.h : header file
//

#if !defined(AFX_CALCCOMDEMODLG_H__1FA925F9_155A_4FF3_AD27_8B4B40AF07B0__INCLUDED_)
#define AFX_CALCCOMDEMODLG_H__1FA925F9_155A_4FF3_AD27_8B4B40AF07B0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CCalcComDemoDlg dialog

class CCalcComDemoDlg : public CDialog
{
// Construction
public:
	CCalcComDemoDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CCalcComDemoDlg)
	enum { IDD = IDD_CALCCOMDEMO_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCalcComDemoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CCalcComDemoDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnJoinbtn();
	afx_msg void OnAddbtn();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CALCCOMDEMODLG_H__1FA925F9_155A_4FF3_AD27_8B4B40AF07B0__INCLUDED_)
