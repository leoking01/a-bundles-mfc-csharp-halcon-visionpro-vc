// MainConsole.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"


//int _tmain(int argc, _TCHAR* argv[])
//{
//	return 0;
//}

#include "CalcCom.h"

int main(  )
{
	char * a1 = "8";
	char * a2 = "2";
	long  n3 = 23;// = "hello,  01.";

	bool res = Add(  a1,a2, & n3 );
	printf( "n3 = %d  \n",  n3 ) ;

	return 0;
}