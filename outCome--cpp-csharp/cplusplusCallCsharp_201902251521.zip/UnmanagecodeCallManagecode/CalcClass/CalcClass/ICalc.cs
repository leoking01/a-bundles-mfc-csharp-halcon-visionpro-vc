﻿using System;
using System.Runtime.InteropServices;

namespace CalcClass
{
    [Guid("254D1FBC-416B-422F-AE39-C923E8803396")]
   public interface ICalc
    {
        [DispId(1)]
        bool Add(string a, string b, out int c);
        [DispId(2)]
        void Join(string a, string b, out string c);
    }
}
