﻿using System;
using System.Runtime.InteropServices;

namespace CalcClass
{
    [Guid("F963B111-39FA-499D-9172-6102C79BB6E5")]
    [ClassInterface(ClassInterfaceType.None)]
    public class Calc : ICalc
    {
        public bool Add(string a, string b, out int c)
        {
            int int_a;
            int int_b;
            if (!Int32.TryParse(a, out int_a))
            {
                c = 0;
                return false;
            }
            if (!Int32.TryParse(b, out int_b))
            {
                c = 0;
                return false;
            }
            c = int_a + int_b;
            return true;
        }

        public void Join(string a, string b, out string c)
        {
            c = a + b;
            return ;
        }
    }
}
