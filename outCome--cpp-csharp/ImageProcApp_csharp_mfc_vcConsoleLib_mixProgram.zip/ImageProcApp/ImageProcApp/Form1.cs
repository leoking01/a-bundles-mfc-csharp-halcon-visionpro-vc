﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Runtime.InteropServices;//Windows.Forms;

namespace ImageProcApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //public

        // 图像灰度化
        private void button1_Click(object sender, EventArgs e)
        {
            //Console.WriteLine("hello.  ");
            bool op = false;
            if (op)
            {
                System.Windows.Forms.MessageBox.Show("button1_Click ", "帮助");
            }

            bool opt = true;//   false;// true;// false;
            if (opt)
            {
                TestCppDll tc = new TestCppDll();
                int c = 0;
                int res = TestCppDll.add_lk(1, 2,  c);
                System.Windows.Forms.MessageBox.Show("res = " + res, "计算1");
                System.Windows.Forms.MessageBox.Show("denoise_call_cpp() = " + TestCppDll.denoise_call_cpp(), "计算2");
                //double ary[20]= new Double( {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19} );
            }
        }

        // 图像灰度化
        private void toolStripLabel1_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.MessageBox.Show("toolStripLabel1_Click  ", "提示");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }

    public class TestCppDll
    {
        public TestCppDll()
        {
        }

        //[DllImport("classLibOpencvBase.dll", CallingConvention = CallingConvention.cdecl)]
        //[DllImport(@"classLibOpencvBase.dll", CallingConvention = CallingConvention.cdecl)]
        //[DllImport(@"classLibOpencvBase.dll", EntryPoint = "add_lk")]
        [DllImport(@"classLibOpencvBase.dll" )]
        public extern     static       int add_lk(int a, int b, int   outVal);

        [DllImport(@"classLibOpencvBase.dll")]
        public extern static int denoise_call_cpp( );
        //extern "C" __declspec(dllexport) int __stdcall  denoise_call_cpp()



        [DllImport("classLibOpencvBase.dll")]
        public static extern IntPtr GetABitmap([MarshalAs(UnmanagedType.LPWStr)] string strFileName);


        //private void MenuItemFileOpenOnClicked(object sender, RoutedEventArgs e)
        //{
        //    OpenFileDialog dialog = new OpenFileDialog();
        //    dialog.Title = "Load an image...";
        //    dialog.Multiselect = false;
        //    if (dialog.ShowDialog() == true)
        //    {
        //        mainGrid.Children.Clear();

        //        IntPtr hBitmap = GetABitmap(dialog.FileName);
        //        Bitmap bitmap = Bitmap.FromHbitmap(hBitmap);
        //        System.Windows.Controls.Image image = new Windows.Controls.Image();
        //        image.Source = Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(hBitmap, ro, Int32Rect.Empty,
        //        Windows.Media.Imaging.BitmapSizeOptions.FromEmptyOptions());
        //        image.Stretch = System.Windows.Media.Stretch.Fill;
        //        DeleteObject(hBitmap);
        //        mainGrid.Children.Add(image);
        //    }
        //}
        [DllImport("classLibOpencvBase.dll")]
        public static extern  bool GetArray(int ElementNumber, double  BaseAddress);




    }
}










