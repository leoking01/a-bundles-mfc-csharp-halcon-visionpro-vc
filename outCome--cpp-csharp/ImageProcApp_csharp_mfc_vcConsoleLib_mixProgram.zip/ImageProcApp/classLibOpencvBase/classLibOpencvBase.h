// classLibOpencvBase.h

#pragma once


#if  (defined WIN32 || defined _WIN32 || defined WINCE  ) &&  defined MYDLL_EXPORTS 
#define  OPENCV_WARP_API_EXPORTS  _declspec(dllexport)
#else
#define  OPENCV_WARP_API_EXPORTS 
#endif 

#include  "ImageProcDlgBase.h"

//#include  <gdi>

namespace TestCppDll
{
	extern "C" __declspec(dllexport) int __stdcall add_lk( int a, int b ,int & outVal  );


	OPENCV_WARP_API_EXPORTS  class  CNaiveCpp 
	{
	public: 
		CNaiveCpp()
		{

		}
		~CNaiveCpp()
		{
		}
	public:
		int  denoise()
		{
			if( 0 )
			{
				//��֧�ֶԻ�����   ��Ȼ�����Եġ���Ȼû�﷨���⡣
				ImageProcDlgBase  ip;
				INT_PTR nResponse = ip.DoModal();
				if (nResponse == IDOK)
				{
				}
				else if (nResponse == IDCANCEL)
				{
				}
			}

			return 20;
		}

		int  getA()
		{
			return 220;
		}

	public:
		
	};

	extern "C" __declspec(dllexport) int __stdcall  denoise_call_cpp();
	


     class  LkProccesion
	{
		// TODO: �ڴ˴����Ӵ���ķ�����
	public:
		LkProccesion()
		{

		}
		~LkProccesion()
		{

		}
	public:
		int  getB()
		{
			CNaiveCpp   ca;
			return ca.getA();
		}
	};



	//extern "C" AFX_API_EXPORT HBITMAP GetABitmap(WCHAR *strFileName)
	//{
	//	Gdiplus::GdiplusStartupInput gdiplusStartupInput;
	//	ULONG_PTR gdiplusToken;
	//	GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, NULL);
	//	Bitmap *bitmap = Bitmap::FromFile(strFileName);
	//	HBITMAP HBitmapToReturn;
	//	bitmap->GetHBITMAP(NULL, &HBitmapToReturn);
	//	GdiplusShutdown(gdiplusToken); 
	//	return HBitmapToReturn;
	//}


	extern"C" AFX_API_EXPORT bool GetArray(int ElementNumber, double*BaseAddress) ;
	extern"C" AFX_API_EXPORT int GetArrayElementNumber() ;

}