// ImageProcDlgBase.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "classLibOpencvBase.h"
#include "ImageProcDlgBase.h"
#include "afxdialogex.h"


// ImageProcDlgBase �Ի���

IMPLEMENT_DYNAMIC(ImageProcDlgBase, CDialogEx)

ImageProcDlgBase::ImageProcDlgBase(CWnd* pParent /*=NULL*/)
	: CDialogEx(ImageProcDlgBase::IDD, pParent)
{

}

ImageProcDlgBase::~ImageProcDlgBase()
{
}

void ImageProcDlgBase::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(ImageProcDlgBase, CDialogEx)
END_MESSAGE_MAP()


// ImageProcDlgBase ��Ϣ��������
