// ������ DLL �ļ���

#include "stdafx.h"

#include "classLibOpencvBase.h"

#include  <string>
#include  <opencv2/opencv.hpp>
using namespace  cv;

namespace TestCppDll
{
	CNaiveCpp  cc;

	__declspec(dllexport)   int  __stdcall  add_lk( int a, int b  ,int & out )
	{
		string nameOfImage;
		nameOfImage = "../../..\\images/c.jpg" ;
		nameOfImage = "../images/c.jpg" ;
		Mat src = imread(  nameOfImage,  1   );
		if(src.data)
		{
			imshow( "src", src );
			waitKey( );
			putText(src, std::to_string((long double ) a ) , Point(10,10), 1, 2, Scalar(255,0,0));
			putText(src, std::to_string((long double ) b ) , Point(10,20), 1, 2, Scalar(255,0,0));
			putText(src, std::to_string((long double ) b+a  ) , Point(10,30), 1, 2, Scalar(255,0,0));
		}
		else
		{
			return -1;
		}

		out = a+ b;
		return  0 ;
	}

	extern "C" __declspec(dllexport) int __stdcall  denoise_call_cpp()
	{
		return cc.denoise();
	}

	int StaticElementNumber =10;
	extern"C" AFX_API_EXPORT bool GetArray(int ElementNumber, double *BaseAddress)
	{
		if (ElementNumber < StaticElementNumber)
		{
			return false;
		} 

		for (int i =0; i < StaticElementNumber; ++i)
		{
			BaseAddress[i] =1.0 / ((double)i +1);
		} 

		return true;
	} 

	extern"C" AFX_API_EXPORT int GetArrayElementNumber()
	{
		return StaticElementNumber;
	}

}