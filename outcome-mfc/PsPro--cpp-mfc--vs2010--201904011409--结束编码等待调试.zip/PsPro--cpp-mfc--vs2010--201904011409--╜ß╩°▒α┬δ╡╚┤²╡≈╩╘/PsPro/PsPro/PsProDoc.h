
// PsProDoc.h : CPsProDoc ��Ľӿ�
//


#pragma once

#include <string>
#include <vector>
#include <iostream>
#include <fstream>

using namespace std;

#include  <fstream>
#include  <iomanip>
using namespace  std;

//typedef vector<double >(3)  tp_vecd3;

class CPsProDoc : public CDocument
{
protected: // �������л�����
	CPsProDoc();
	DECLARE_DYNCREATE(CPsProDoc)

public:
	//double * m_pdata;

	vector<vector< double > >  m_vecData;
	int  m_data_width;
	int  m_data_height;
	static const int  m_dim = 3;

	//void CPsProDoc::OnFileWrite() ;
	//void CPsProDoc::OnFileRead() ;

// ����
public:

// ����
public:

// ��д
public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
#ifdef SHARED_HANDLERS
	virtual void InitializeSearchContent();
	virtual void OnDrawThumbnail(CDC& dc, LPRECT lprcBounds);
#endif // SHARED_HANDLERS

// ʵ��
public:
	virtual ~CPsProDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// ���ɵ���Ϣӳ�亯��
protected:
	DECLARE_MESSAGE_MAP()

#ifdef SHARED_HANDLERS
	// ����Ϊ�����������������������ݵ� Helper ����
	void SetSearchContent(const CString& value);
#endif // SHARED_HANDLERS

public:
	BOOL CPsProDoc::OnSaveDocument(LPCTSTR lpszPathName) ;
	BOOL CPsProDoc::OnOpenDocument(LPCTSTR lpszPathName) ;
	//void CPsProDoc::OnFileReopen() ;
	int  CPsProDoc::OnFileSaveAs();

	afx_msg void OnFileReOpen();
};
