
// PsProDoc.cpp : CPsProDoc ���ʵ��
//

#include "stdafx.h"
// SHARED_HANDLERS ������ʵ��Ԥ��������ͼ������ɸѡ�������
// ATL ��Ŀ�н��ж��壬�����������Ŀ�����ĵ����롣
#ifndef SHARED_HANDLERS
#include "PsPro.h"
#endif

#include "PsProDoc.h"

#include <propkey.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CPsProDoc

IMPLEMENT_DYNCREATE(CPsProDoc, CDocument)

BEGIN_MESSAGE_MAP(CPsProDoc, CDocument)
	ON_COMMAND(ID_FILE_REOPEN, &CPsProDoc::OnFileReOpen)
END_MESSAGE_MAP()


// CPsProDoc ����/����

CPsProDoc::CPsProDoc()
{
	// TODO: �ڴ�����һ���Թ������

}

CPsProDoc::~CPsProDoc()
{
}

BOOL CPsProDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: �ڴ��������³�ʼ������
	// (SDI �ĵ������ø��ĵ�)

	//m_pdata = NULL;
	m_data_height = 3;
	m_data_width = 4;

	for( int i=0;i<m_data_height;i++ )
	{
		for( int j=0;j<m_data_width;j++ )
		{
			vector<double > item;
			for( int k=0;k<m_dim;k++ )
			{
				item.push_back(   10*i+j + (i+j)/10.0+ k +0.1  );
			}
			m_vecData.push_back(  item );
		}
	}
	  

	return TRUE;
}




// CPsProDoc ���л�

void CPsProDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		//// TODO: �ڴ����Ӵ洢����
		if( 0 )
		{
			ar<< m_data_width ;//= 20;
			ar<< m_data_height ;//= 10;
			for( int i=0;i<m_data_height;i++ )
			{
				for( int j=0;j<m_data_width;j++ )
				{
					ar<<  m_vecData[i* m_data_width+  j][0];
					ar<<  m_vecData[i* m_data_width+  j][1];
					ar<<  m_vecData[i* m_data_width+  j][2];
				}
			}
		}
	}
	else
	{
		//// TODO: �ڴ����Ӽ��ش���
		if( 0 )
		{
			ar>> m_data_width ;//= 20;
			ar>>  m_data_height ;//= 10;
			for( int i=0;i<m_data_height;i++ )
			{
				for( int j=0;j<m_data_width;j++ )
				{
					ar>>   m_vecData[i* m_data_width+  j][0];
					ar>>   m_vecData[i* m_data_width+  j][1];
					ar>>   m_vecData[i* m_data_width+  j][2];
				}
			}
		}
	}
}


#ifdef  ggh
void CPsProDoc::OnFileWrite() 
{
	// TODO: Add your command handler code here
	CFile file(_T("1.txt"),CFile::modeCreate|CFile::modeWrite);
	CArchive ar(&file,CArchive::store);
	int i=4;
	char ch='a';
	float f=1.3f;
	CString str("hello word!");
	ar<<i<<ch<<f<<str;
}


void CPsProDoc::OnFileRead() 
{
	// TODO: Add your command handler code here
	CFile file(_T("1.txt"),CFile::modeRead);
	CArchive ar(&file,CArchive::load);
	int i;
	char ch;
	float f;
	CString str;
	CString strResult;
	ar>>i>>ch>>f>>str;   //ע�⣬ǰ��İ���������˳��д�����ݵģ�������͵ð���������˳���ȡ����
	strResult.Format( _T("%d,%c,%f,%s"),i,ch,f,str);
	AfxMessageBox(strResult);
}
#endif



#ifdef SHARED_HANDLERS

// ����ͼ��֧��
void CPsProDoc::OnDrawThumbnail(CDC& dc, LPRECT lprcBounds)
{
	// �޸Ĵ˴����Ի����ĵ�����
	dc.FillSolidRect(lprcBounds, RGB(255, 255, 255));

	CString strText = _T("TODO: implement thumbnail drawing here");
	LOGFONT lf;

	CFont* pDefaultGUIFont = CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT));
	pDefaultGUIFont->GetLogFont(&lf);
	lf.lfHeight = 36;

	CFont fontDraw;
	fontDraw.CreateFontIndirect(&lf);

	CFont* pOldFont = dc.SelectObject(&fontDraw);
	dc.DrawText(strText, lprcBounds, DT_CENTER | DT_WORDBREAK);
	dc.SelectObject(pOldFont);
}

// �������������֧��
void CPsProDoc::InitializeSearchContent()
{
	CString strSearchContent;
	// ���ĵ����������������ݡ�
	// ���ݲ���Ӧ�ɡ�;���ָ�

	// ����:  strSearchContent = _T("point;rectangle;circle;ole object;")��
	SetSearchContent(strSearchContent);
}

void CPsProDoc::SetSearchContent(const CString& value)
{
	if (value.IsEmpty())
	{
		RemoveChunk(PKEY_Search_Contents.fmtid, PKEY_Search_Contents.pid);
	}
	else
	{
		CMFCFilterChunkValueImpl *pChunk = NULL;
		ATLTRY(pChunk = new CMFCFilterChunkValueImpl);
		if (pChunk != NULL)
		{
			pChunk->SetTextValue(PKEY_Search_Contents, value, CHUNK_TEXT);
			SetChunkValue(pChunk);
		}
	}
}

#endif // SHARED_HANDLERS

// CPsProDoc ���

#ifdef _DEBUG
void CPsProDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CPsProDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CPsProDoc ����

#define  xxx 
#ifdef  xxx
BOOL CPsProDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{
	CFile file;
	CFileException fe;

	if (!file.Open(lpszPathName, CFile::modeRead | CFile::shareDenyWrite, &fe))
	{
		ReportSaveLoadException(lpszPathName, &fe,FALSE, 
			AFX_IDP_FAILED_TO_OPEN_DOC);

		return FALSE;
	}
	file.Close();

	DeleteContents();
	BeginWaitCursor();

	SetPathName(lpszPathName);			// �����ļ�����	
	SetModifiedFlag(FALSE);				// ��ʼ���ͱ��ΪFALSE


	//  read
	ifstream    fr;
	//�����￪ʼ����ת��������һ���궨��
	CString  picPath = CString(  lpszPathName  );
	USES_CONVERSION;
	//����ת��
	char* keyChar = T2A(  picPath .GetBuffer(0));
	picPath.ReleaseBuffer();
	string picpath(keyChar);
	string nameRead = picpath;
	AfxMessageBox(   CString( nameRead.c_str() )  );

	TRY
	{
		fr.open(  nameRead,  ios::in  ) ;
		BeginWaitCursor();
		double   temp;
		fr>>  m_data_height ;// <<endl;
				fr>>  m_data_width  ;// <<endl;
		AfxMessageBox(   CString( (  to_string((long double ) m_data_height ) 
			+ " , "+   (to_string((long double ) m_data_width ) )   ).c_str() )  );
		//fr>> temp;

		//fr>> temp;
		m_vecData.clear();
		for( int i=0;i<m_data_height;i++ )
		{
			for( int j=0;j<m_data_width;j++ )
			{
				vector<double > item;
				fr>> temp;
				item.push_back(   temp );
				fr>> temp;
				item.push_back(   temp );
				fr>> temp;
				item.push_back(   temp );
				//fr>> temp;
				m_vecData.push_back(   item );
			}
			//fr>> endl;
			//fr>> temp;
		}
		//fo<<endl;
		//fr>> temp;
		fr.close();

	}
	CATCH (CException, eSave)
	{
		//file.Abort();
		EndWaitCursor();
		//ReportSaveLoadException(lpszPathName,eSave,TRUE,
		//	AFX_IDP_FAILED_TO_SAVE_DOC);
		AfxMessageBox(   CString( "��ȡ���ݴ���" )  );
		return FALSE;
	}
	END_CATCH



	return TRUE;
}


BOOL CPsProDoc::OnSaveDocument(LPCTSTR lpszPathName) 
{
	CFile file;
	CFileException fe;

	//if (!file.Open(lpszPathName, CFile::modeCreate |CFile::modeReadWrite |CFile::typeText | CFile::shareExclusive, &fe))
	if (!file.Open(lpszPathName, CFile::modeCreate |CFile::modeReadWrite |CFile::shareExclusive , &fe))
	{
		ReportSaveLoadException(lpszPathName,&fe,TRUE,AFX_IDP_INVALID_FILENAME);
		return FALSE;
	}
	file.Close();


	if( 0 )
	{
		CArchive ar(&file,CArchive::store);
		ar<< m_data_width ;//= 20;
		ar<< m_data_height ;//= 10;
		for( int i=0;i<m_data_height;i++ )
		{
			for( int j=0;j<m_data_width;j++ )
			{
				ar<<  m_vecData[i* m_data_width+  j][0];
				ar<<  m_vecData[i* m_data_width+  j][1];
				ar<<  m_vecData[i* m_data_width+  j][2];
			}
		}
		ar.Close();
	}

	
	BOOL bSuccess = FALSE;
	bSuccess = TRUE;
	TRY
	{
		//file.Write(  &m_data_width ,   sizeof( int  ));
		ofstream    fo;
		//�����￪ʼ����ת��������һ���궨��
		CString  picPath = CString(  lpszPathName  );
		USES_CONVERSION;
		//����ת��
		char* keyChar = T2A(  picPath .GetBuffer(0));
		picPath.ReleaseBuffer();
		string picpath(keyChar);
		string nameOut = picpath;
		//AfxMessageBox(   CString( nameOut.c_str() )  );

		fo.open(  nameOut,  ios::out  ) ;
		BeginWaitCursor();
		
		fo<<  m_data_height <<endl;
		fo<<  m_data_width  <<endl;
		for( int i=0;i<m_data_height;i++ )
		{
			for( int j=0;j<m_data_width;j++ )
			{
				fo<< setw(8)<<  m_vecData[i* m_data_width+  j][0];
				fo<< setw(8)<<  m_vecData[i* m_data_width+  j][1];
				fo<< setw(8)<<  m_vecData[i* m_data_width+  j][2];
			}
			fo<<endl;
		}
		fo<<endl;
		fo.close();
		
	}
	CATCH (CException, eSave)
	{
		file.Abort();
		EndWaitCursor();
		ReportSaveLoadException(lpszPathName,eSave,TRUE,
			AFX_IDP_FAILED_TO_SAVE_DOC);

		return FALSE;
	}
	END_CATCH

		EndWaitCursor();
	SetModifiedFlag(FALSE);

	if (!bSuccess)
	{
		// ����ʧ�ܣ�������������ʽ��DIB�����Զ�ȡ���ǲ��ܱ���
		// ������SaveDIB��������
		CString strMsg;
		strMsg = "�޷����浱ǰ���ݣ�";
		MessageBox(NULL, strMsg, _T("ϵͳ��ʾ"), MB_ICONINFORMATION | MB_OK);
	}
	return bSuccess;
}


int  CPsProDoc::OnFileSaveAs()
{
	return 0;
}



//void CPsProDoc::OnFileReopen() 
//{
//
//}

#endif 






#ifdef  zzz


BOOL CFreTransDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{
	CFile file;
	CFileException fe;

	if (!file.Open(lpszPathName, CFile::modeRead | CFile::shareDenyWrite, &fe))
	{
		ReportSaveLoadException(lpszPathName, &fe,FALSE, 
			AFX_IDP_FAILED_TO_OPEN_DOC);

		return FALSE;
	}

	DeleteContents();

	BeginWaitCursor();

	if(m_pDibImage != NULL)
	{
		delete m_pDibImage;
		m_pDibImage = NULL;
	}
	m_pDibImage = new CDibImage;

	TRY
	{
		m_hDIB = m_pDibImage->ReadDIBFile(file);
	}
	CATCH (CFileException, eLoad)
	{
		file.Abort();
		EndWaitCursor();

		ReportSaveLoadException(lpszPathName, eLoad,FALSE, 
			AFX_IDP_FAILED_TO_OPEN_DOC);

		m_hDIB = NULL;

		if(m_pDibImage != NULL)
		{
			delete m_pDibImage;
			m_pDibImage = NULL;
		}

		return FALSE;
	}
	END_CATCH

		InitDIBData();
	EndWaitCursor();

	// �ж϶�ȡ�ļ��Ƿ�ɹ�
	if (m_hDIB == NULL)
	{
		CString strMsg;
		strMsg = "��ȡͼ��ʱ�����������ǲ�֧�ָ����͵�ͼ���ļ���";
		MessageBox(NULL, strMsg, "ϵͳ��ʾ", MB_ICONINFORMATION | MB_OK);

		if(m_pDibImage != NULL)
		{
			delete m_pDibImage;
			m_pDibImage = NULL;
		}

		return FALSE;
	}

	SetPathName(lpszPathName);			// �����ļ�����	
	SetModifiedFlag(FALSE);				// ��ʼ���ͱ��ΪFALSE

	return TRUE;
}

BOOL CFreTransDoc::OnSaveDocument(LPCTSTR lpszPathName) 
{
	CFile file;
	CFileException fe;

	if (!file.Open(lpszPathName, CFile::modeCreate |CFile::modeReadWrite 
		| CFile::shareExclusive, &fe))
	{
		ReportSaveLoadException(lpszPathName,&fe,TRUE,AFX_IDP_INVALID_FILENAME);
		return FALSE;
	}

	BOOL bSuccess = FALSE;
	TRY
	{
		BeginWaitCursor();
		bSuccess = m_pDibImage->SaveDIB(m_hDIB, file);
		file.Close();
	}
	CATCH (CException, eSave)
	{
		file.Abort();
		EndWaitCursor();
		ReportSaveLoadException(lpszPathName,eSave,TRUE,
			AFX_IDP_FAILED_TO_SAVE_DOC);

		return FALSE;
	}
	END_CATCH

		EndWaitCursor();
	SetModifiedFlag(FALSE);

	if (!bSuccess)
	{
		// ����ʧ�ܣ�������������ʽ��DIB�����Զ�ȡ���ǲ��ܱ���
		// ������SaveDIB��������
		CString strMsg;
		strMsg = "�޷�����BMPͼ��";
		MessageBox(NULL, strMsg, "ϵͳ��ʾ", MB_ICONINFORMATION | MB_OK);
	}

	return bSuccess;
}

void CFreTransDoc::OnFileReopen() 
{
	// ���´�ͼ�񣬷��������޸�

	// �жϵ�ǰͼ���Ƿ��Ѿ����Ķ�
	if (IsModified())
	{
		if (MessageBox(NULL, "���´�ͼ�񽫶�ʧ���иĶ����Ƿ������", 
			"ϵͳ��ʾ", MB_ICONQUESTION | MB_YESNO) == IDNO)
		{
			return;
		}
	}

	CFile file;
	CFileException fe;
	CString strPathName;
	strPathName = GetPathName();

	if (!file.Open(strPathName, CFile::modeRead | CFile::shareDenyWrite, &fe))
	{
		ReportSaveLoadException(strPathName,&fe,FALSE,AFX_IDP_FAILED_TO_OPEN_DOC);

		return;
	}

	BeginWaitCursor();

	if(m_pDibImage != NULL)
	{
		delete m_pDibImage;
		m_pDibImage = NULL;
	}
	m_pDibImage = new CDibImage;

	TRY
	{
		m_hDIB = m_pDibImage->ReadDIBFile(file);
	}
	CATCH (CFileException, eLoad)
	{
		file.Abort();
		EndWaitCursor();

		ReportSaveLoadException(strPathName,eLoad,FALSE,AFX_IDP_FAILED_TO_OPEN_DOC);

		m_hDIB = NULL;
		if(m_pDibImage != NULL)
		{
			delete m_pDibImage;
			m_pDibImage = NULL;
		}

		return;
	}
	END_CATCH

		InitDIBData();

	if (m_hDIB == NULL)
	{
		CString strMsg;
		strMsg = "��ȡͼ��ʱ�����������ǲ�֧�ָ����͵�ͼ���ļ���";
		MessageBox(NULL, strMsg, "ϵͳ��ʾ", MB_ICONINFORMATION | MB_OK);

		EndWaitCursor();

		if(m_pDibImage != NULL)
		{
			delete m_pDibImage;
			m_pDibImage = NULL;
		}

		return;
	}

	SetModifiedFlag(FALSE);
	UpdateAllViews(NULL);
	EndWaitCursor();

	return;
}

#endif 




void CPsProDoc::OnFileReOpen()
{
	// TODO: �ڴ�����������������
	// �жϵ�ǰͼ���Ƿ��Ѿ����Ķ�
	if (IsModified())
	{
		if (MessageBox(NULL, _T("���´�ͼ�񽫶�ʧ���иĶ����Ƿ������"), 
			_T("ϵͳ��ʾ"), MB_ICONQUESTION | MB_YESNO) == IDNO)
		{
			return;
		}
	}

	CFile file;
	CFileException fe;
	CString strPathName;
	strPathName = GetPathName();

	if (!file.Open(strPathName, CFile::modeRead | CFile::shareDenyWrite, &fe))
	{
		ReportSaveLoadException(strPathName,&fe,FALSE,AFX_IDP_FAILED_TO_OPEN_DOC);

		return;
	}

	BeginWaitCursor();

	TRY
	{
		//m_hDIB = m_pDibImage->ReadDIBFile(file);
	}
	CATCH (CFileException, eLoad)
	{
		file.Abort();
		EndWaitCursor();

		ReportSaveLoadException(strPathName,eLoad,FALSE,AFX_IDP_FAILED_TO_OPEN_DOC);

		//m_hDIB = NULL;
		//if(m_pDibImage != NULL)
		//{
		//	delete m_pDibImage;
		//	m_pDibImage = NULL;
		//}

		return;
	}
	END_CATCH

		SetModifiedFlag(FALSE);
	UpdateAllViews(NULL);
	EndWaitCursor();

	return;
}
