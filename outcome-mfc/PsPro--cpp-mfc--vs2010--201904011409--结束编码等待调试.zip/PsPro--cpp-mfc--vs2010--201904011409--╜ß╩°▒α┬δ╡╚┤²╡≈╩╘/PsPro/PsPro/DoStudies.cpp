#include "StdAfx.h"
#include "DoStudies.h"


DoStudies::DoStudies(void)
{
}


DoStudies::~DoStudies(void)
{
}
