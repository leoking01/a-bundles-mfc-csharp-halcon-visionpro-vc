
// PsProView.h : CPsProView ��Ľӿ�
//

#pragma once


class CPsProView : public CView
{
protected: // �������л�����
	CPsProView();
	DECLARE_DYNCREATE(CPsProView)

// ����
public:
	CPsProDoc* GetDocument() const;

// ����
public:

// ��д
public:
	virtual void OnDraw(CDC* pDC);  // ��д�Ի��Ƹ���ͼ
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// ʵ��
public:
	virtual ~CPsProView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// ���ɵ���Ϣӳ�亯��
protected:
	afx_msg void OnFilePrintPreview();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnPathswitchfuncPathswitchfunc_sample();
	afx_msg void OnPathswitchfuncTest01_full();

	void CPsProView::fetchFileName(string & nameOut) ;
	int opt_sample ;
	void test_rotate();

	void CPsProView::readTxtWords( string nameOfTxt,  
		std::vector<std:: vector<  double > > & vec_datas , int  w,int h, int dim    );
	void CPsProView::showTxtWords( std::vector<std:: vector<  double > >  vec_datas, int w,int h,int m_dim    );
};

#ifndef _DEBUG  // PsProView.cpp �еĵ��԰汾
inline CPsProDoc* CPsProView::GetDocument() const
   { return reinterpret_cast<CPsProDoc*>(m_pDocument); }
#endif

